Hi.

Thank you for purchasing our theme.

Import below link into your Theme Options:

https://fotofly.marketifythemes.com/1/wp-admin/admin-ajax.php?action=redux_download_options-redux_demo&secret=25dd4a6e0b628b955d20df037e8936f4

Old files (deprecated since WordPress v5.5) of the theme were removed since Fotofly v2.2

Best Regards