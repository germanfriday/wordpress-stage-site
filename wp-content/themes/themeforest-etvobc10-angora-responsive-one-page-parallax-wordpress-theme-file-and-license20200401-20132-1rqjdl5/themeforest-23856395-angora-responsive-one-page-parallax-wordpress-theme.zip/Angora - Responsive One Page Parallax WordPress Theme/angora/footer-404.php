<?php global $angoraConfig; ?>
		
		<?php AngoraTheme::inlineScripts( get_the_ID( ) ); ?>
		
		<?php wp_footer( ); ?>
		
	</body>
</html>