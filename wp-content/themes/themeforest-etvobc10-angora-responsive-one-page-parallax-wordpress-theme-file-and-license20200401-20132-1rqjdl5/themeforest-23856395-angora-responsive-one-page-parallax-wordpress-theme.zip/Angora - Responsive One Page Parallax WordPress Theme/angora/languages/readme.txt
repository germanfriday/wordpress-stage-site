Find the angora.pot file with default English language to translate to.

Edit the *.pot file with an editor like POEDIT (https://poedit.net/) to do the desired translations and save the xx_XX.mo file in this directory so that WordPress and whatever translation plugin you're using is be able to locate it.

Download POEDIT software(https://poedit.net/) and to run it. Select from the menu 'File' > 'Create catalog from POT file...', open file from  '/angora/languages/angora.pot'.

Set the options, that appear in opened windows and click on all words and sentences, and at the bottom enter your translation. Save file with your localization. For example from Germany need to be de_DE. And you will get 2 new files 'de_DE.mo' and 'de_DE.po'.

Please see below links with information how to do this:
1. http://www.yacs.fr/article-2937-poedit-tips-for-new-translators
2. https://www.youtube.com/watch?v=-YkuCdLB4hA

Enjoy,
AthenaStudio