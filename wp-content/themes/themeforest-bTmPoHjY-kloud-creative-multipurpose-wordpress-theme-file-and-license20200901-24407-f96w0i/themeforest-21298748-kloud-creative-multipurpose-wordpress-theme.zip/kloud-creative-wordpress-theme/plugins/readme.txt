Dear value customers,

Thank you so much for choosing Kloud - Creative Multipurpose WordPress Theme.

When you purchase a theme from ThemeForest that bundles WPBakery Page Builder, Revolution Slider plugins or other premium plugins, you are free to use these Premium plugins with the theme. However, your Kloud purchase does not give you individual Visual Composer and Revolution Slider licenses that allow you to activate or download these plugins as you wish. Activation doesn’t mean the plugin will not work but only that you cannot receive direct updates. Please don't worry if you see warning messages about the plugin license activation.

You can use these plugins with the Kloud theme and you are fully compliant with the Envato’s policy, but you cannot activate them as the owner (so don't try to use the Kloud purchase code to activate one of these plugins).

New plugin updates will be provided when we issue new theme updates. As soon as a new version is available for download, we will surely update the theme after we will fully test the plugins to make sure there are no bugs that will conflict with our own update. We will also fully test new theme versions before releasing them on ThemeForest.

How to update latest plugin: https://www.youtube.com/watch?v=WhAHwvRK8uM

Regards,
The JWSThemes Support Team