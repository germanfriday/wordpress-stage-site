<form method="get" id="searchform" class="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>">
    <div>
        <input type="text" value="<?php echo get_search_query(); ?>" name="s" id="s" placeholder="Search ..." />
        <button id="searchsubmit" type="submit"><span class="ion-ios-search"></span></button>
    </div>
</form>