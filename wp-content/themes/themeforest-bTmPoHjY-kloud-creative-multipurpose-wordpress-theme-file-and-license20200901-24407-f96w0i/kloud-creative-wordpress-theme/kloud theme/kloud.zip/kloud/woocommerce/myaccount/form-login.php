<div class="form_login">
    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 hidden-sm hidden-xs">
        <?php echo do_shortcode ('[userpro_social_connect width="400px"]') ?>
    </div>
    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
        <?php echo do_shortcode ('[userpro template=login]') ?>
    </div>
    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 hidden-lg hidden-md">
        <?php echo do_shortcode ('[userpro_social_connect width="400px"]') ?>
    </div>
</div>