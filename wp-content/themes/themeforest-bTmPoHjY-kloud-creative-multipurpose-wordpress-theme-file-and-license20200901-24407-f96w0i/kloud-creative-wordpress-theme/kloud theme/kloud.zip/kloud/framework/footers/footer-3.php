<?php 
/**
 * Layout Name: Footer kloud One
 * Preview Image: /assets/images/footers/footer-kloud-v3.jpg
**/
?>
<div id="footer-jws" class="footer-v3">
    <?php echo do_shortcode( cs_get_option( 'footer-3' ) ); ?>    
</div>
</div><!-- #wrap -->