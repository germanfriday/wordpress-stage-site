<?php 
/**
 * Layout Name: Footer kloud One
 * Preview Image: /assets/images/footers/footer-kloud-v4.jpg
**/
?>
<div id="footer-jws" class="footer-v7">
    <?php echo do_shortcode( cs_get_option( 'footer-7' ) ); ?>    
</div>
</div><!-- #wrap -->