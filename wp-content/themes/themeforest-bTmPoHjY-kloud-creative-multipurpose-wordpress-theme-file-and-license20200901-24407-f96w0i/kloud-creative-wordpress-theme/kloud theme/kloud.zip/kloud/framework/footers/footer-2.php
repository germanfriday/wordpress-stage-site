<?php 
/**
 * Layout Name: Footer kloud One
 * Preview Image: /assets/images/footers/footer-kloud-v1.jpg
**/
?>
<div id="footer-jws" class="footer-v2">
    <?php echo do_shortcode( cs_get_option( 'footer-2' ) ); ?>    
</div>
</div><!-- #wrap -->