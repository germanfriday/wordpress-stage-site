=== KLOUD ===
Author: the JWSThemes team
Requires at least: WordPress 4.6.0
Tested up to: WordPress 5.5.x
Version: 1.0.6
Description: Kloud is an engaging and enticing, visually stimulating and malleable, professional and polished, responsive WordPress creative multipurpose website theme.
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Tags: 	agency, business, clean, corporate, creative, designer, flat, freelance, modern, one page, page builder, parallax, photography, portfolio
== Installation ==
1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's kloud.zip file. Click Install Now.
3. Click Activate to use your new theme right away. 

=== CHANGE LOG ===
V1.0.6 – Aug 28, 2020
# Tested up to PHP 7.3.x.
# Tested up to WordPress 5.4.x.
# Compatible with WooCommerce 4.3.x
# Fixed some bugs.
# Updated: WooCommerce template.
# Updated: demo data for new buyers.
# Fixed: Instagram.

V1.0.5 – Jan 18, 2019
# Gutenberg compatible.
# Fixed small CSS.
# Compatible with WooCommerce 3.5.x

V1.0.3 – Jun, 18 2018
# Updated: compatible with WooCommerce 3.4.x
# Fixed: small CSS.

V1.0.2 – May, 30 2018
# Updated: compatible with WooCommerce 3.5.x
# Fixed: small CSS.

V1.0.1 – May, 05 2018
# Updated: One Click Import All Demo Data.
# Fixed: small CSS.

V1.0.0 – May, 03 2018
# Release.