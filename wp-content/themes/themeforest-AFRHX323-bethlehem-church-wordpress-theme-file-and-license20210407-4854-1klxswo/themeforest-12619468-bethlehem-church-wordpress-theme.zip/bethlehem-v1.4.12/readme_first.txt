Bethlehem - Wordpress Church Theme

The theme's documentation and the customer support are provided online. Here are a few useful links on getting started with the theme.

1. Theme Documentation - https://transvelo.github.io/docs/bethlehem/
2. Support - https://themeforest.net/item/bethlehem-church-wordpress-theme/12619468/support
3. Getting Started with WooCommerce - https://docs.woothemes.com/documentation/plugins/woocommerce/getting-started/
4. Getting Started with Wordpress - https://codex.wordpress.org/Getting_Started_with_WordPress