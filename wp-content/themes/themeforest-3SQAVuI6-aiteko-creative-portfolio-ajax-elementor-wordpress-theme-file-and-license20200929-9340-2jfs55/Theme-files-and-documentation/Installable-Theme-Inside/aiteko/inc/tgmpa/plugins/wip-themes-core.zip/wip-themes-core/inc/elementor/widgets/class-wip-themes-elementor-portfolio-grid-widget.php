<?php
/**
 * custom elementor portfolio grid widget
 *
 * @package Elementor
 * @subpackage WIP-Themes Core
 * @since 1.0
 */

/**
 * Elementor portfolio grid Widget.
 *
 * Elementor widget that inserts portfolio post type.
 *
 * @since 1.0.0
 */
class Wip_Themes_Elementor_Portfolio_Grid_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve portfolio widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'portfolio-grid';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Portfolio Grid', 'wip-themes-core' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-posts-masonry';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'wip-themes' ];
	}

	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Settings', 'wip-themes-core' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'number_post',
			[
				'label' => esc_html__( 'Number of post', 'wip-themes-core' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'input_type' => 'number',
				'placeholder' => '',
				'default' => 10,
				'description' => esc_html__( 'Enter "-1" to show all posts', 'wip-themes-core' ),
			]
		);

		$this->add_control(
			'order_by',
			[
				'label' => esc_html__( 'Order by', 'wip-themes-core' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'date',
				'description' => '',
				'options' => [
					'ID'    => esc_html__( 'Post ID', 'wip-themes-core' ),
					'date'  => esc_html__( 'Post date', 'wip-themes-core' ),
					'title' => esc_html__( 'Post title', 'wip-themes-core' ),
					'rand'  => esc_html__( 'Random order', 'wip-themes-core' ),
				],
			]
		);

		$this->add_control(
			'order',
			[
				'label' => esc_html__( 'Order', 'wip-themes-core' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'DESC',
				'description' => '',
				'options' => [
					'ASC'  => esc_html__( 'Ascending', 'wip-themes-core' ),
					'DESC' => esc_html__( 'Descending', 'wip-themes-core' ),
				],
			]
		);

		$portfolio__cats = wip_themes_core_taxonomies_options( 'portfolio-cat' );
		$this->add_control(
			'category',
			[
				'label' => esc_html__( 'Portfolio category', 'wip-themes-core' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'all',
				'description' => '',
				'options' => $portfolio__cats,
			]
		);

		$this->add_control(
			'show_portfolio_category',
			[
				'label' => esc_html__( 'Display category?', 'wip-themes-core' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'On', 'wip-themes-core' ),
				'label_off' => esc_html__( 'Off', 'wip-themes-core' ),
				'return_value' => 'yes',
				'default' => '',
				'description' => esc_html__( 'Show/hide portfolio category from list.', 'wip-themes-core' ),
			]
		);

		$this->add_control(
			'show_pagination',
			[
				'label' => esc_html__( 'Pagination', 'wip-themes-core' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'On', 'wip-themes-core' ),
				'label_off' => esc_html__( 'Off', 'wip-themes-core' ),
				'return_value' => 'yes',
				'default' => '',
				'description' => esc_html__( 'Enable/disable pagination. Please prevent to enable multiple paginations in the same page.', 'wip-themes-core' ),
			]
		);

		$this->end_controls_section();

	}

	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

		$settings    = $this->get_settings_for_display();
		$post_number = $settings['number_post'];
		$order_by    = $settings['order_by'];
		$order       = $settings['order'];
		$category    = $settings['category'];
		$pagination  = $settings['show_pagination'];
		$show_cat    = $settings['show_portfolio_category'];

		$post_args = array(
			'post_type'           => 'portfolio',
			'post_status'         => 'publish',
			'posts_per_page'      => intval($post_number),
			'ignore_sticky_posts' => 1,
			'orderby'             => $order_by,
			'order'               => $order,
		);

		if ( 'yes' === $pagination ) {
			$paged = ( get_query_var( 'paged' ) ) ? absint( get_query_var( 'paged' ) ) : 1;
			if ( is_front_page() ) {
				$paged = ( get_query_var( 'page' ) ) ? absint( get_query_var( 'page' ) ) : 1;
			}
			if ( isset( $_GET['custom_paged'] ) ) {
				$paged = (int) $_GET['custom_paged'];
			}
			$post_args['paged'] = $paged;
		} else {
			// no pagination? we should stick to page 1 then.
			$post_args['paged'] = 1;
		}

		if ( $category !== 'all' && intval( $category ) > 0 ) {
			$post_args['tax_query'] = array();
			$post_args['tax_query'][] = array(
					'taxonomy' => 'portfolio-cat',
					'field'    => 'id',
					'terms'    => intval( $category ),
					'operator' => 'IN'
			);
		}

		$p_query = new WP_Query( $post_args );
		if ( $p_query->have_posts() ) :
			$GLOBALS['show_cat'] = $show_cat;
			print '<div class="portfolio-grids">' . "\n";
			print '<div class="portfolio-grid-sizer"></div>' . "\n";

			$i=0;
			while ( $p_query->have_posts() ) :
				$p_query->the_post();

				$i++;

				get_template_part( 'template-parts/portfolio/loop', 'grid' );

				if ( $i < 2 || $i === 2 ) {
					$more_class = ( $i === 2 ) ? ' wide' : '';
					print '<div class="portfolio-grids-spacer portfolio-grid' . $more_class . '"></div>';
				}

			endwhile;

			unset($i);

			if ( isset( $GLOBALS['show_cat'] ) ) {
				unset( $GLOBALS['show_cat'] );
			}

			print '</div><!-- .portfolio-grids -->' . "\n";

			if ( 'yes' === $pagination ) {
				the_wip_themes_core_custom_paginate_links( array(
					'prev_text' => '<span class="screen-reader-text">' . esc_html__( 'Previous page', 'wip-themes-core' ) . '</span>',
					'next_text' => '<span class="screen-reader-text">' . esc_html__( 'Next page', 'wip-themes-core' ) . '</span>',
					'before_page_number' => '<span class="meta-nav screen-reader-text">' . esc_html__( 'Page', 'wip-themes-core' ) . ' </span>',
					'current' => ( is_front_page() ) ? max( 1, get_query_var('page') ) : max( 1, get_query_var('paged') ),
					'total' => $p_query->max_num_pages,
				) );
			}

			wp_reset_postdata();

		else :

			print '<h4>'. esc_html__( 'No posts found!', 'wip-themes-core' ).'</h4>';

		endif;
	}
}
