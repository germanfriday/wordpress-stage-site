<?php
/*
Plugin Name: WIP-Themes Core
Plugin URI: https://themeforest.net/user/wip-themes
Description: Core functions and features required by WIP-Themes Themes
Version: 1.0.4
Author: WIP-Themes
Author URI: https://themeforest.net/user/wip-themes
License: GPL
Text Domain: wip-themes-core
Copyright: https://themeforest.net/user/wip-themes
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Wip_Themes_Core' ) ) {
	class Wip_Themes_Core {
		// var $plugin_url
		public $plugin_url;

		// var $plugin_path
		public $plugin_path;

		// var self::$instance
		private static $instance;

		/**
		 * Main plugin's instance
		 *
		 * @access public
		 * @since 1.0
		 * @return instance of Wip_Themes_Core
		 */
		public static function instance() {
			if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Wip_Themes_Core ) ) {
				self::$instance = new Wip_Themes_Core;
				self::$instance->define_constants();
				self::$instance->call_files();

				register_activation_hook( __FILE__, 'wip_themes_cores_activate' );
				register_deactivation_hook( __FILE__, 'wip_themes_cores_deactivate' );
				add_action( 'admin_init', array( self::$instance, '_run' )  );
				add_action( 'init', array( self::$instance, 'init' ) );
				add_action( 'widgets_init', array( self::$instance, 'register_widgets' ) );
			}

			return self::$instance;
		}

		/**
		 * Plugin inits
		 *
		 * @access public
		 * @since 1.0
		 * @return void
		 */
		public function init() {
			do_action( 'wip_themes_core_before_init' );

			$this->_i18n();

			do_action( 'wip_themes_core_init' );
		}

		/**
		 * Throw error on object clone
		 *
		 * The whole idea of the singleton design pattern is that there is a single
		 * object therefore, we don't want the object to be cloned.
		 *
		 * @since 1.0
		 * @access protected
		 * @return void
		 */
		public function __clone() {
			// Cloning instances of the class is forbidden
			_doing_it_wrong( __FUNCTION__, __( 'Cheatin&#8217; huh?', 'wip-themes-core' ), '1.0' );
		}

		/**
		 * Define some constants using by plugin
		 *
		 * @access private
		 * @since 1.0
		 * @return void
		 */
		private function define_constants() {
			if ( ! defined( 'WIP_THEMES_CORE_VER' ) )
				define( "WIP_THEMES_CORE_VER", '1.0.3' );

			if ( ! defined( 'WIP_THEMES_CORE_PATH' ) )
				define( "WIP_THEMES_CORE_PATH", dirname( __FILE__ ) );

			if ( ! defined( 'WIP_THEMES_CORE_URL' ) )
				define( "WIP_THEMES_CORE_URL", untrailingslashit( plugins_url( '/', __FILE__ ) ) );

			if ( ! defined( 'WIP_THEMES_CORE_FILE' ) )
				define( 'WIP_THEMES_CORE_FILE', plugin_basename( __FILE__ ) );
		}

		/**
		 * Call required files
		 *
		 * @access private
		 * @since 1.0
		 * @return void
		 */
		private function call_files() {
			require_once( WIP_THEMES_CORE_PATH . '/inc/init.php' );
			require_once( WIP_THEMES_CORE_PATH . '/inc/functions.php' );
			require_once( WIP_THEMES_CORE_PATH . '/inc/class-wip-themes-core-cpt.php' );
			require_once( WIP_THEMES_CORE_PATH . '/inc/class-wip-themes-core-sass-production.php' );
			require_once( WIP_THEMES_CORE_PATH . '/admin/class-wip-themes-core-metabox.php' );
			require_once( WIP_THEMES_CORE_PATH . '/inc/instagram-module.php' );
			require_once( WIP_THEMES_CORE_PATH . '/inc/custom-widgets.php' );
			require_once( WIP_THEMES_CORE_PATH . '/inc/class-wip-themes-core-compiler-scss.php' );
			require_once( WIP_THEMES_CORE_PATH . '/inc/class-wip-themes-elementor-factory.php' );
			
			if ( is_admin() ) {
				require_once( WIP_THEMES_CORE_PATH . '/admin/custom-post-manage-column.php' );
				require_once( WIP_THEMES_CORE_PATH . '/admin/custom-tax-fields.php' );
				require_once( WIP_THEMES_CORE_PATH . '/admin/custom-author-socials.php' );
			}
		}

		/**
		 * Register plugin's translation
		 *
		 * @access public
		 * @since 1.0
		 * @return void
		 */
		public function _i18n() {
			load_plugin_textdomain( 'wip-themes-core', false, 'wip-themes-core/langs' );
		}

		/**
		 * get and set plugin url
		 *
		 * @access public
		 * @since 1.0
		 * @return string plugin public url
		 */
		public function plugin_url() {
			if ( self::$instance->plugin_url )
				return self::$instance->plugin_url;

			if ( defined( "WIP_THEMES_CORE_URL" ) ) {
				return self::$instance->plugin_url = WIP_THEMES_CORE_URL;
			} else {
				return self::$instance->plugin_url = untrailingslashit( plugins_url( '/', __FILE__ ) );
			}
		}

		/**
		 * get and set plugin path
		 *
		 * @access public
		 * @since 1.0
		 * @return string plugin path
		 */
		public function plugin_path() {
			if ( self::$instance->plugin_path )
				return self::$instance->plugin_path;

			if ( defined( "WIP_THEMES_CORE_PATH" )) {
				return self::$instance->plugin_path = WIP_THEMES_CORE_PATH;
			} else {
				return self::$instance->plugin_path = dirname( __FILE__ );
			}
		}

		/**
		 * Register custom widgets
		 *
		 * @access public
		 * @since 1.0
		 * @return void
		 */
		public function register_widgets() {
			if ( defined( 'WIP_THEMES_CORE_NO_CUSTOM_WIDGETS' ) ) {
				return false;
			}

			$defaults = array( 'Wip_Themes_About_Widget', 'Wip_Themes_Blog_Posts_Widget', 'Wip_Themes_Featured_Posts_Widget', 'Wip_Themes_Instagram_Widget', 'Wip_Themes_FB_Likebox_Widget' );
			$custom_widgets = apply_filters( 'wip_themes_core_custom_widgets', $defaults );
			
			if ( ! empty( $custom_widgets ) ) {
				foreach ( $custom_widgets as $widget_name ) {
					register_widget( $widget_name );
				}
				unset( $widget_name );
			}
		}

		/**
		 * Run**
		 *
		 * @access public
		 * @since 1.0
		 * @return void
		 */
		public function _run() {
			if ( ! current_theme_supports( 'wipthemes-themes' ) ) {
				add_action( 'admin_notices', 'wip_themes_core_plugin_error_notice' );
				deactivate_plugins( WIP_THEMES_CORE_FILE );
			}
		}
	}
}

Wip_Themes_Core::instance();
