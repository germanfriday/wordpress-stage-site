window.Core99crvWidget = window.Core99crvWidget || {};

Core99crvWidget.helper = function($) {
	var g={
		init: function() {
			var d=this;
			this.imageUpload();
			$( document ).ajaxComplete(function() {
				d.imageUpload();
			});
		},
		imageUpload: function() {
			var d=this, hndles=$('.ce-wd-ml');
			if ( hndles.length ) {
				$.each( hndles, function(i,hndle) {
					var input_id = $(hndle).data('id'),
					cont = $('#'+input_id),
					wrp = $('#wrp-'+input_id),
					bg_frame,
					_custom_media = true,
					_orig_send_attachment = wp.media.editor.send.attachment,
					_del = wrp.find('.ce-wd-ml-remove');

					if ( cont.val() === '' ) {
						_del.hide();
					}

					_del.unbind().on( 'click', function(e) {
						e.preventDefault();
						wrp.find('.ce-widget-image-preview').html('No image selected.');
						cont.val('');
						cont.trigger('change');
						_del.hide();
					});

					$(hndle).unbind().on( 'click', function(e) {
						e.preventDefault();

						var insertSimpleImage = wp.media.controller.Library.extend({
						    defaults :  _.defaults({
						            id: input_id,
						            title: 'Select Image',
						            multiple : false,
						            type : 'image'
						      }, wp.media.controller.Library.prototype.defaults )
						});

						if ( typeof bg_frame !== 'undefined' ) {
							bg_frame.open();
							return;
						}

						bg_frame = wp.media({
							frame: 'select',
							state : input_id,
						    states : [
						        new insertSimpleImage()
						    ],
							title: 'Select Image',
							multiple: false,
							library: {type:'image'}
						});

						bg_frame.on( 'select', function() {
							var selection = bg_frame.state(input_id).get('selection'),
								attachment = selection.toJSON(),
								sizey, pr, buildReturns;

							sizey = attachment[0].sizes;
							pr = attachment[0].sizes.full.url;
							buildReturns = '<img src="'+pr+'" alt="" />';

							wrp.find('.ce-widget-image-preview').html( buildReturns );
							cont.val( attachment[0].id );
							cont.trigger('change');
							_del.show();

							_del.unbind().on( 'click', function(e) {
								e.preventDefault();
								wrp.find('.ce-widget-image-preview').html('No image selected.');
								cont.val('');
								cont.trigger('change');
								_del.hide();
							});
						});
						bg_frame.open();
					});
				});
			}
		}
	};
	g.init();
	return g;
}( window.jQuery );