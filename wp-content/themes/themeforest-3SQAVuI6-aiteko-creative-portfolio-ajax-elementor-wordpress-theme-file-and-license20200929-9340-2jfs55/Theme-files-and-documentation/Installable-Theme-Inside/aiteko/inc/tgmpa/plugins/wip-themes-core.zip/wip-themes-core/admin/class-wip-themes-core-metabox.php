<?php
/**
 * Metaboxes register
 *
 * @since 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

if ( ! class_exists( 'Wip_Themes_Core_Metabox' ) ) {

	class Wip_Themes_Core_Metabox {
		/**
		 * var $public
		 *
		 * @access public
		 * @since 1.0
		 */
		public $options = array();

		/**
		 * Wip_Themes_Core_Metabox's instance
		 *
		 * @access public
		 * @since 1.0
		 * @return instance of Wip_Themes_Core_Metabox
		 */
		public function __construct( $options = array() ) {
			if ( ! empty( $options ) ) {
				$this->options = $options;
				
				$this->init();
			}
		}

		public function init() {
			add_action( 'add_meta_boxes', array( $this, 'add_meta_box' ) );
			add_action( 'save_post', array( $this, 'save' ) );
		}

		public function add_meta_box() {
			if ( ! empty( $this->options ) ) {
				$id = $this->options['id'];
				$title = $this->options['title'];
				$post_type =$this->options['post_type'];
				
				add_meta_box( $id, $title, [ $this, 'metabox_ui' ], $post_type, 'side' );
			}
		}

		/**
		 * save the metabox value
		 *
		 * @access public
		 * @since 1.0
		 * @return void
		 */
		public function save( $post_id ) {
			$is_autosave = wp_is_post_autosave( $post_id );
			$is_revision = wp_is_post_revision( $post_id );

			if ( $is_autosave || $is_revision ) {
				return;
			}

			if ( empty( $this->options ) ) {
				return;
			}

			$options = $this->options['options'];
			foreach( $options as $id => $opt ) {
				if ( isset( $_POST[ trim($id) ] ) ) {
					update_post_meta( $post_id, trim($id), sanitize_text_field( $_POST[ trim($id) ] ) );
				}
			}
			unset( $opt );
		}

		/**
		 * register the metabox
		 *
		 * @access public
		 * @since 1.0
		 * @return void
		 */
		public function metabox_ui( $post ) {
			if ( empty( $this->options ) ) {
				return false;
			}
			$options = $this->options['options'];

			foreach( $options as $id => $opt ) {
				$ui = $this->ui( $post, $opt['type'], $opt['args'] );
				print $ui;
			}
			unset( $opt );
		}

		public function ui( $post, $type = '', $args = array() ) {
			if ( empty( $type ) || empty( $args ) ) {
				return false;
			}

			$interface = '';
			switch ($type) {
				case 'select':
					$interface = $this->ui_select( $post, $args );
					break;

				case 'text':
				default:
					$interface = $this->ui_text( $post, $args );
					break;
			}

			return $interface;
		}

		/**
		 * Text field
		 *
		 * @return string
		 */
		public function ui_text( $post, $args = array() ) {
			$args = wp_parse_args( $args,
				array(
					'id' => '',
					'label' => '',
					'description' => '',
					'default' => ''
				) );

			if ( empty( $args['id'] ) ) {
				return false;
			}

			$value = get_post_meta( $post->ID, $args['id'], true );
			if ( ! $value ) {
				$value = $args['default'];
			}

			$ui = '<div class="components-panel__row">' . "\n";
			$ui .= '<label for="' . esc_attr( $args['id'] ) . '">' . $args['label'] . '</label>';
			$ui .= '<div class="components-base-control"><div class="components-base-control__field">';

			$ui .= '<input type="text" name="' . esc_attr( $args['id'] ) . '" id="' . esc_attr( $args['id'] ) . '" value="' . esc_attr( $value ) . '">';

			$ui .= '</div></div>' . "\n";
			$ui .= '</div>' . "\n";

			if ( ! empty( $args['description'] ) ) {
				$ui .= '<div><small>' . stripslashes( $args['description'] ) . '</small></div>';
			}

			return $ui;
		}

		/**
		 * Select option
		 *
		 * @return string
		 */
		public function ui_select( $post, $args = array() ) {
			$args = wp_parse_args( $args,
				array(
					'id' => '',
					'label' => '',
					'options' => array(),
					'description' => '',
					'default' => ''
				) );

			if ( empty( $args['id'] ) ) {
				return false;
			}

			$value = get_post_meta( $post->ID, $args['id'], true );
			if ( ! $value ) {
				$value = $args['default'];
			}

			$ui = '<div class="components-panel__row">' . "\n";
			$ui .= '<label for="' . esc_attr( $args['id'] ) . '">' . $args['label'] . '</label>';
			$ui .= '<div class="components-base-control"><div class="components-base-control__field">';

			$ui .= '<select name="' . esc_attr( $args['id'] ) . '" id="' . esc_attr( $args['id'] ) . '">';

			foreach( $args['options'] as $val => $name ) {
				$ui .= '<option value="' . esc_attr( $val ) . '" ' . selected( $val, $value, false ) . '>' . $name . '</option>' . "\n";
			}

			$ui .= '</select>' . "\n";

			$ui .= '</div></div>' . "\n";
			$ui .= '</div>' . "\n";

			if ( ! empty( $args['description'] ) ) {
				$ui .= '<div><small>' . stripslashes( $args['description'] ) . '</small></div>';
			}

			return $ui;
		}
	}
}
