<?php
/**
 * Some helper functions
 *
 * @since 1.0
 * @author WIP-Themes
 */

/**
 * Check post featured by ID
 *
 * @return bool
 */
function wip_themes_post_is_featured( $post_id = false ) {
	if ( ! $post_id ) {
		return false;
	}

	$val = get_post_meta( $post_id, '_wip_themes_featured', true );
	$featured = ( $val === "1" ) ? true : false;

	return $featured;
}

/**
 * Create path
 *
 * @use WP_Filesystem
 * @return bool
 */
function wip_themes_core_create_path( $path ) {
	// use WP_Filesystem
	if ( ! function_exists( 'WP_Filesystem' ) ) {
		require_once( ABSPATH . 'wp-admin/includes/file.php' );
	}

	WP_Filesystem();
	global $wp_filesystem;
	if ( ! $wp_filesystem->is_dir( $path ) ) {
		$wp_filesystem->mkdir( $path );
	}
}

/**
 * Write to file, use for refresh the custom css or editor style css
 *
 * @use WP_Filesystem
 * @return bool
 */
function wip_themes_core_write_to_file( $file = '', $content = '' ) {
	// use WP_Filesystem
	if ( ! function_exists( 'WP_Filesystem' ) ) {
		require_once( ABSPATH . 'wp-admin/includes/file.php' );
	}
	
	WP_Filesystem();
	global $wp_filesystem;

	$fs_chmod_file = ( fileperms( ABSPATH . 'index.php' ) & 0777 | 0644 );
	if ( defined('FS_CHMOD_FILE') ) {
		$fs_chmod_file = FS_CHMOD_FILE;
	}

	if ( ! $wp_filesystem->put_contents( $file, $content, $fs_chmod_file ) ) {
		return false;
	}

	return true;
}

if ( ! function_exists( 'wip_themes_core_get_tax_lists' ) ) {
	/**
	 * get the taxonomy lists, mostly used in theme option as select option values
	 * @param $taxonomy = taxonomy name @default 'category'
	 *
	 * @access public
	 * @return html select field
	 */
	function wip_themes_core_get_tax_lists( $taxonomy = 'category', $name = '', $id = '', $class = 'postform', $show_option_all = '', $selected = 0, $walker = "", $custom_args = array() ){
		$args = array(
			'show_option_all' => $show_option_all,
			'hide_empty'	=> 0, 
			'name' 			=> $name,
			'id'			=>  ( $id == "" ) ? $name : $id,
			'class'			=> $class,
			'hierarchical' 	=> true,
			'taxonomy'		=> $taxonomy,
			'selected'		=> $selected,
			'echo'			=> 0,
			'walker'		=> $walker
			);

		if ( ! empty( $custom_args ) ) {
			foreach( $custom_args as $name => $value ) {
				$args[$name] = $value;
			}
			unset( $name );
		}
		//var_dump($args);
		$options = 	wp_dropdown_categories($args);

		$options = str_replace('&nbsp;&nbsp;&nbsp;', "&mdash; ", $options);
		return $options;
	}
}

if ( ! function_exists( 'wip_themes_core_taxonomies_options' ) ) {
	function wip_themes_core_taxonomies_options( $taxonomy = 'category' ) {
		$categories = get_categories( array(
			'taxonomy' => $taxonomy,
		) );

		$options = array();
		$options['all'] = esc_html__( 'All categories', 'wip-themes-core' );
		if ( ! empty( $categories ) ) {
			foreach( $categories as $cat ) {
				$options[ $cat->term_id ] = $cat->name;
			}
			unset( $cat );
		}

		return $options;
	}
}

function wip_themes_core_custom_paginate_links( $args = array() ) {
	$args = wp_parse_args(
		$args, array(
			'base' => str_replace( 999999999, '%#%', esc_url( get_pagenum_link( 999999999 ) ) ),
			'format' => '?paged=%#%',
			'total' => 1,
			'current' => 0,
			'show_all' => false,
			'end_size' => 1,
			'mid_size' => 2,
			'prev_next' => true,
			'prev_text' => esc_html__( 'Previous page', 'wip-themes-core' ),
			'next_text' => esc_html__( 'Next page', 'wip-themes-core' ),
			'type' => 'plain',
			'add_args' => false,
			'add_fragment' => '',
			'before_page_number' => '',
			'after_page_number' => ''
		)
	);

	return paginate_links( $args );
}

function the_wip_themes_core_custom_paginate_links( $args = array() ) {
	$paging = wip_themes_core_custom_paginate_links( $args );
	if ( $paging ) {
		print '<nav class="navigation pagination"><div class="nav-links">' . $paging . '</div></nav>';
	}
}

/**
 * Get the google fonts from the API or in the cache
 *
 * @param  integer $amount
 * @return String
 */
function wip_themes_core_get_google_fonts( $amount = 30 ) {
	$directory = WIP_THEMES_CORE_PATH;
	$fontFile = $directory . '/cache/google-web-fonts.txt';

	//Total time the file will be cached in seconds, set to a week
	$cachetime = 86400 * 7;

	if ( ! function_exists( 'WP_Filesystem' ) ) {
		require_once( ABSPATH . 'wp-admin/includes/file.php' );
	}

	WP_Filesystem();
	global $wp_filesystem;

	$fs_chmod_file = ( fileperms( ABSPATH . 'index.php' ) & 0777 | 0644 );
	if ( defined('FS_CHMOD_FILE') ) {
		$fs_chmod_file = FS_CHMOD_FILE;
	}

	$content = false;
	if ( file_exists( $fontFile ) ) {
		if ( $cachetime < filemtime($fontFile) ) {
			$fonts_data = $wp_filesystem->get_contents($fontFile);

			if ( $fonts_data ) {
				$content = json_decode( $fonts_data );
			} else {
				$googleApi = 'https://www.googleapis.com/webfonts/v1/webfonts?sort=popularity&key=AIzaSyCtHefEYoYwZRMUqF_EcYNBTFfPLsZFRE8';
				$fontContent = wp_remote_get( esc_url($googleApi) );

				$content = json_decode( $fontContent['body'] );
				if ( isset( $content->error ) ) {
					return false;
				}

				$wp_filesystem->put_contents( $fontFile, $fontContent['body'], $fs_chmod_file );
				
			}

		} else {
			$googleApi = 'https://www.googleapis.com/webfonts/v1/webfonts?sort=popularity&key=AIzaSyCtHefEYoYwZRMUqF_EcYNBTFfPLsZFRE8';
			$fontContent = wp_remote_get( esc_url($googleApi) );
			
			$content = json_decode( $fontContent['body'] );
			if ( isset( $content->error ) ) {
				$fonts_data = $wp_filesystem->get_contents($fontFile);
				$content = json_decode( $fonts_data );
			} else {
				$wp_filesystem->put_contents( $fontFile, $fontContent['body'], $fs_chmod_file );
			}
		}
	} else {
		$dir = $wp_filesystem->find_folder( $directory . "/cache" );
		$newfile = trailingslashit($dir) . "google-web-fonts.txt";

		$googleApi = 'https://www.googleapis.com/webfonts/v1/webfonts?sort=popularity&key=AIzaSyCtHefEYoYwZRMUqF_EcYNBTFfPLsZFRE8';
		$fontContent = wp_remote_get( esc_url($googleApi) );

		$content = json_decode( $fontContent['body'] );
		if ( isset( $content->error ) ) {
			$wp_filesystem->put_contents( trailingslashit($dir) . "google-error.txt", $fontContent['body'], $fs_chmod_file );
			return false;
		}		

		$wp_filesystem->put_contents( $newfile, $fontContent['body'], $fs_chmod_file );
	}

	if ( ! $content ) {
		return false;
	}

	if ( $amount == 'all' ) {
		return $content->items;
	} else {
		return array_slice( $content->items, 0, $amount );
	}
}

function wip_themes_elementor_in_edit_screen() {
	if ( ! defined( 'ELEMENTOR_VERSION' ) ) {
		return false;
	}

	if ( \Elementor\Plugin::$instance->preview->is_preview_mode() ) {
		return true;
	}
	return false;
}

function wip_themes_footer_add_jsid() {
	if ( ! wip_themes_elementor_in_edit_screen() ) {
		return false;
	}

	?>
<script>
jQuery( window ).on( 'elementor/frontend/init', function() {
	elementorFrontend.hooks.addAction( 'frontend/element_ready/portfolio-grid.default', function( $scope ) {
		jQuery(window).trigger("ElemPortoAdded");
	});
});
</script>
	<?php
}
add_action( 'wp_footer', 'wip_themes_footer_add_jsid', 99 );
