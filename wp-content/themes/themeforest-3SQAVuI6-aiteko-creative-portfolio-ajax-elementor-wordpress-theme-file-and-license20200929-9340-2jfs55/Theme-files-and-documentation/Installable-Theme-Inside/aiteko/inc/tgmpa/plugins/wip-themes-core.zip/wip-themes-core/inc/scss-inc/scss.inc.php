<?php
if ( version_compare( PHP_VERSION, '5.4' ) < 0 ) {
    throw new \Exception('scssphp requires PHP 5.4 or above');
}

if ( ! class_exists('Leafo\ScssPhp\Version', false) ) {

    include_once WIP_THEMES_CORE_PATH . '/inc/scss-inc/src/Base/Range.php';
    include_once WIP_THEMES_CORE_PATH . '/inc/scss-inc/src/Block.php';
    include_once WIP_THEMES_CORE_PATH . '/inc/scss-inc/src/Colors.php';
    include_once WIP_THEMES_CORE_PATH . '/inc/scss-inc/src/Compiler.php';
    include_once WIP_THEMES_CORE_PATH . '/inc/scss-inc/src/Compiler/Environment.php';
    include_once WIP_THEMES_CORE_PATH . '/inc/scss-inc/src/Exception/CompilerException.php';
    include_once WIP_THEMES_CORE_PATH . '/inc/scss-inc/src/Exception/ParserException.php';
    include_once WIP_THEMES_CORE_PATH . '/inc/scss-inc/src/Exception/RangeException.php';
    include_once WIP_THEMES_CORE_PATH . '/inc/scss-inc/src/Exception/ServerException.php';
    include_once WIP_THEMES_CORE_PATH . '/inc/scss-inc/src/Formatter.php';
    include_once WIP_THEMES_CORE_PATH . '/inc/scss-inc/src/Formatter/Compact.php';
    include_once WIP_THEMES_CORE_PATH . '/inc/scss-inc/src/Formatter/Compressed.php';
    include_once WIP_THEMES_CORE_PATH . '/inc/scss-inc/src/Formatter/Crunched.php';
    include_once WIP_THEMES_CORE_PATH . '/inc/scss-inc/src/Formatter/Debug.php';
    include_once WIP_THEMES_CORE_PATH . '/inc/scss-inc/src/Formatter/Expanded.php';
    include_once WIP_THEMES_CORE_PATH . '/inc/scss-inc/src/Formatter/Nested.php';
    include_once WIP_THEMES_CORE_PATH . '/inc/scss-inc/src/Formatter/OutputBlock.php';
    include_once WIP_THEMES_CORE_PATH . '/inc/scss-inc/src/Node.php';
    include_once WIP_THEMES_CORE_PATH . '/inc/scss-inc/src/Node/Number.php';
    include_once WIP_THEMES_CORE_PATH . '/inc/scss-inc/src/Parser.php';
    include_once WIP_THEMES_CORE_PATH . '/inc/scss-inc/src/SourceMap/Base64.php';
    include_once WIP_THEMES_CORE_PATH . '/inc/scss-inc/src/SourceMap/Base64VLQ.php';
    include_once WIP_THEMES_CORE_PATH . '/inc/scss-inc/src/SourceMap/SourceMapGenerator.php';
    include_once WIP_THEMES_CORE_PATH . '/inc/scss-inc/src/Type.php';
    include_once WIP_THEMES_CORE_PATH . '/inc/scss-inc/src/Util.php';
    include_once WIP_THEMES_CORE_PATH . '/inc/scss-inc/src/Version.php';
}
