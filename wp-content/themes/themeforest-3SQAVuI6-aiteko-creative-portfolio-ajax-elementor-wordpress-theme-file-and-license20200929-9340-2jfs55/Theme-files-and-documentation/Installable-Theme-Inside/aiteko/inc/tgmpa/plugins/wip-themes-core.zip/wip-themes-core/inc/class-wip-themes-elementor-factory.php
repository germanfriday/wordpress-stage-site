<?php
/**
 * Helper class for custom elementor widgets
 *
 * @package Elementor
 * @subpackage WIP-Themes Core
 * @since 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Elementor not active.
if ( ! did_action( 'elementor/loaded' ) ) {
	return false;
}

// Elementor version checks.
if ( ! version_compare( ELEMENTOR_VERSION, '2.3.8', '>=' ) ) {
	add_action( 'admin_notices', 'wip_themes_core_notice_elementor_version' );
	return false;
}

/**
 * Main Elementor Factory Class
 *
 * The main class that initiates and runs the plugin.
 *
 * @since 1.0.0
 */
final class Wip_Themes_Elementor_Factory {
	/**
	 * Instance
	 *
	 * @since 1.0.0
	 *
	 * @access private
	 * @static
	 *
	 * @var Wip_Themes_Elementor_Factory The single instance of the class.
	 */
	private static $_instance = null;

	/**
	 * Instance
	 *
	 * Ensures only one instance of the class is loaded or can be loaded.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 * @static
	 *
	 * @return Wip_Themes_Elementor_Factory An instance of the class.
	 */
	public static function instance() {

		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;

	}

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function __construct() {

		add_action( 'plugins_loaded', [ $this, 'init' ] );

	}

	/**
	 * Initialize the module
	 *
	 * Load the plugin only after Elementor (and other plugins) are loaded.
	 *
	 * Fired by `plugins_loaded` action hook.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function init() {

		add_action( 'elementor/elements/categories_registered', [ $this, 'add_elementor_widget_categories' ] );
		add_action( 'elementor/widgets/widgets_registered', [ $this, 'init_widgets' ] );
		//add_action( 'elementor/controls/controls_registered', [ $this, 'init_controls' ] );
	}

	/**
	 * Register our new widget category to elementor
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function add_elementor_widget_categories( $elements_manager ) {

		$elements_manager->add_category(
			'wip-themes',
			[
				'title' => __( 'WIP Themes', 'wip-themes-core' ),
				'icon' => 'fa fa-plug',
			]
		);
	}

	/**
	 * Init Widgets
	 *
	 * Include widgets files and register them
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function init_widgets() {

		// Include Widget files
		require_once( WIP_THEMES_CORE_PATH . '/inc/elementor/widgets/class-wip-themes-elementor-portfolio-widget.php' );
		require_once( WIP_THEMES_CORE_PATH . '/inc/elementor/widgets/class-wip-themes-elementor-portfolio-grid-widget.php' );

		// Register widget
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Wip_Themes_Elementor_Portfolio_Widget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Wip_Themes_Elementor_Portfolio_Grid_Widget() );

	}
}

Wip_Themes_Elementor_Factory::instance();
