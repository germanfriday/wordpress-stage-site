<?php
// Team ([team])
class Sena_Shortcode_Team {
	
	static $teamColumns;
	
	public static function team( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'column' => '1/4'
		), $atts ) );
		
		self::$teamColumns = Sena_Shortcodes::getColumnsNumber( $column );
		
		return '<div class="row">' . do_shortcode( $content ) . '</div>';
	}
	
	public static function vc_team() {
		vc_map( array(
		   	"name" => esc_html__( "Team Members", "sena-addons" ),
		   	"base" => "team",
		   	"icon" => 'ti-user',
            "description" => esc_html__( "Company workers", "sena-addons" ),
			"as_parent" => array(
            	"only" => "worker"
   			),
			"js_view" => "VcColumnView",
			"category" => esc_html__( "Sena", "sena-addons" ),
			"params" => array(
				array(
				 	"type" => "dropdown",
				 	"holder" => "div",
				 	"class" => "",
				 	"heading" => esc_html__( "Column", "sena-addons" ),
				 	"param_name" => "column",
				 	"value" => array(
						"1/2" => '1/2',
						"1/3" => '1/3',
						"1/4" => '1/4',
						"1/6" => '1/6'
					),
					"std" => "1/4",
				 	"description" => "",
					"admin_label" => true,
			  	),
			)
		));
	}

	// Worker ([worker])
	public static function worker( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'image'         => '',
			'activity'		=> '',
			'twitter'		=> '',
			'facebook'		=> '',
			'linkedin'		=> '',
			'instagram'		=> '',
			'dribbble'		=> ''
		), $atts ) );
		
		$img = '';
        
        if ( ! empty( $image ) ) {
             $img = wp_get_attachment_url( $image );
        }
		
		$social = '';
		
		// Twitter
		$twitter = vc_build_link( $twitter );
		
		if ( strlen( $twitter['url'] ) > 0 ) {
			$target = strlen( $twitter['target'] ) > 0 ? 'target="' . $twitter['target'] . '"' : '';
			$social .= '<a href="' . esc_url( $twitter['url'] ) . '" title="Twitter" ' . $target . '><i class="fab fa-twitter"></i></a>';
		}
		
		// Facebook
		$facebook = vc_build_link( $facebook );
		
		if ( strlen( $facebook['url'] ) > 0 ) {
			$target = strlen( $facebook['target'] ) > 0 ? 'target="' . $facebook['target'] . '"' : '';
			$social .= '<a href="' . esc_url( $facebook['url'] ) . '" title="Facebook" ' . $target . '><i class="fab fa-facebook-f"></i></a>';
		}
		
		// LinkedIn
		$linkedin = vc_build_link( $linkedin );
		
		if ( strlen( $linkedin['url'] ) > 0 ) {
			$target = strlen( $linkedin['target'] ) > 0 ? 'target="' . $linkedin['target'] . '"' : '';
			$social .= '<a href="' . esc_url( $linkedin['url'] ) . '" title="LinkedIn" ' . $target . '><i class="fab fa-linkedin-in"></i></a>';
		}
		
		// Instagram
		$instagram = vc_build_link( $instagram );
		
		if ( strlen( $instagram['url'] ) > 0 ) {
			$target = strlen( $instagram['target'] ) > 0 ? 'target="' . $instagram['target'] . '"' : '';
			$social .= '<a href="' . esc_url( $instagram['url'] ) . '" title="Instagram" ' . $target . '><i class="fab fa-instagram"></i></a>';
		}
		
		// Dribbble
		$dribbble = vc_build_link( $dribbble );
		
		if ( strlen( $dribbble['url'] ) > 0 ) {
			$target = strlen( $dribbble['target'] ) > 0 ? 'target="' . $dribbble['target'] . '"' : '';
			$social .= '<a href="' . esc_url( $dribbble['url'] ) . '" title="Dribbble" ' . $target . '><i class="fab fa-dribbble"></i></a>';
		}
		
		$output = '<div class="col-md-' . self::$teamColumns . '">
						<div class="team-member res-margin">
							<div class="team-image">
								<p><img src="' . $img . '" alt="' . do_shortcode( $content ) . '" /></p>
								' . ( ! empty( $social ) ? '<div class="team-social"><div class="team-social-inner">' . $social . '</div></div>' : '' ) . '
							</div>
							<div class="team-details">
								<h5 class="title">' . do_shortcode( $content ) . '</h5>
								<span class="position">' . $activity . '</span>
							</div>
						</div>
				   </div>';
		
		return $output;
	}
	
	public static function vc_worker() {
		vc_map( array(
		   	"name" => esc_html__( "Worker", "sena-addons" ),
		   	"base" => "worker",
		   	"icon" => 'ti-user',
			"as_child" => array(
            	"only" => "team"
   			),
		   	"category" => esc_html__( "Sena", "sena-addons" ),
		   	"params" => array(
				array(
					"type"        => "attach_image",
					"heading"     => esc_html__( "Image", "sena-addons" ),
					"param_name"  => "image",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Name", "sena-addons" ),
					"param_name"  => "content",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Activity", "sena-addons" ),
					"param_name"  => "activity",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
				array(
					'type' 		  => 'vc_link',
					'heading' 	  => esc_html__( "Twitter URL", "sena-addons" ),
					'param_name'  => 'twitter',
					'description' => "",
					"admin_label" => true,
			  	),
				array(
					'type' 		  => 'vc_link',
					'heading' 	  => esc_html__( "Facebook URL", "sena-addons" ),
					'param_name'  => 'facebook',
					'description' => "",
					"admin_label" => true,
			  	),
				array(
					'type' 		  => 'vc_link',
					'heading' 	  => esc_html__( "LinkedIn URL", "sena-addons" ),
					'param_name'  => 'linkedin',
					'description' => "",
					"admin_label" => true,
			  	),
				array(
					'type' 		  => 'vc_link',
					'heading' 	  => esc_html__( "Instagram URL", "sena-addons" ),
					'param_name'  => 'instagram',
					'description' => "",
					"admin_label" => true,
			  	),
				array(
					'type' 		  => 'vc_link',
					'heading' 	  => esc_html__( "Dribbble URL", "sena-addons" ),
					'param_name'  => 'dribbble',
					'description' => "",
					"admin_label" => true,
			  	),
			)
		));
	}
    
}

add_shortcode( 'team', 				array( 'Sena_Shortcode_Team', 'team' ) );
add_shortcode( 'worker', 			array( 'Sena_Shortcode_Team', 'worker' ) );
add_action( 'vc_before_init', 		array( 'Sena_Shortcode_Team', 'vc_team' ) );
add_action( 'vc_before_init', 		array( 'Sena_Shortcode_Team', 'vc_worker' ) );

// Nested shortcodes
add_action( 'vc_before_init', function() {
    
    // Features extend
	if (class_exists( 'WPBakeryShortCodesContainer' )) {
		class WPBakeryShortCode_team extends WPBakeryShortCodesContainer {};
	}
	
	if (class_exists( 'WPBakeryShortCode' )) {
		class WPBakeryShortCode_worker extends WPBakeryShortCode {};
	}
    
});

