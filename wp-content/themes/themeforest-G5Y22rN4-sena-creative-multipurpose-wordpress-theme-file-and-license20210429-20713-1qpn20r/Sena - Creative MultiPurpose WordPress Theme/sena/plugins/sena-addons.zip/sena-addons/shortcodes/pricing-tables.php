<?php
// Pricing tables ([pricing_table])
class Sena_Shortcode_Pricing_Tables {
    
    static $pricingTableColumns;
    
    public static function pricingTable( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'column' => '1/3'
		), $atts ) );

		self::$pricingTableColumns = Sena_Shortcodes::getColumnsNumber( $column );

		return '<div class="row">' . do_shortcode( $content ) . '</div>';
	}
	
	public static function vc_pricingTable() {
		vc_map( array(
		   	"name" => esc_html__( "Pricing Tables", "sena-addons" ),
		   	"base" => "pricing_table",
		   	"icon" => 'ti-money',
            "description" => esc_html__( "Pricing plans", "sena-addons" ),
			"as_parent" => array(
            	"only" => "plan"
   			),
			"js_view" => "VcColumnView",
			"category" => esc_html__( "Sena", "sena-addons" ),
			"params" => array(
				array(
				 	"type" => "dropdown",
				 	"holder" => "div",
				 	"class" => "",
				 	"heading" => esc_html__( "Column", "sena-addons" ),
				 	"param_name" => "column",
				 	"value" => array(   
						esc_html__( "1/2 - Two Plans", "sena-addons" ) => '1/2',
						esc_html__( "1/3 - Three Plans", "sena-addons" ) => '1/3',
						esc_html__( "1/4 - Four Plans", "sena-addons" ) => '1/4'
					),
					"std" => "1/3",
				 	"description" => "",
					"admin_label" => true,
			  	),
			)
		));
	}

	// Pricing table plan ([plan])
	public static function plan( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'featured'		=> 'no',
			'title'         => '',
			'icon'          => '',
			'currency'    	=> '',
			'rate'    		=> '',
			'time'    		=> 'Month',
			'label'        	=> 'Purchase',
			'ribbon'        => '',
			'url'           => ''
		), $atts ) );
		
		$url = vc_build_link( $url );
		$target = strlen( $url['target'] ) > 0 ? $url['target'] : '';
		$url = strlen( $url['url'] ) > 0 ? $url['url'] : '';
		
		$cls = ( $featured == "true" ? "btn btn-rounded btn-white btn-inverse" : "btn btn-default btn-rounded" );
		$featured = ( $featured == "true" ? "featured" : "" );
		
		if ( $ribbon!="" ) {
			$ribbon = '<div class="card-ribbon"><span>' . $ribbon . '</span></div>';
		}
		
		return '<div class="col-md-' . self::$pricingTableColumns . '">
					<div class="price-table res-margin ' . $featured . '">
						<div class="price-title">
							<div class="' . esc_attr( $icon ) . '"></div>
							<h5>' . esc_html( $title ) . '</h5>
							<div class="price-rate"><span class="currency"><i class="' . esc_attr( $currency ) . '"></i></span> <span class="rate">' . esc_html( $rate ) . '</span><span class="time">' . esc_html( $time ) . '</span></div>
						</div>
						<div class="price-content">
							<div class="content">
								' . do_shortcode( $content ) . '
								<div class="price-button"> 
									<a href="' . esc_url( $url ) . '" '. ( ( $target != '' && $target != '_self' ) ? ' target="' . esc_attr( $target ) . '"' : '' ) . ' class="' . esc_attr( $cls ) . '">' . esc_html( $label ) . '</a> 
								</div>
							</div>
						</div>						
						' . $ribbon . '
					</div>						
				</div>';
	}
	
	public static function vc_plan() {
		vc_map( array(
		   	"name" => esc_html__( "Plan", "sena-addons" ),
		   	"base" => "plan",
		   	"icon" => 'ti-money',
			"as_child" => array(
            	"only" => "pricing_table"
   			),
		   	"category" => esc_html__( "Sena", "sena-addons" ),
		   	"params" => array(
				array(
					"type"        => "checkbox",
					"heading"     => esc_html__( "Featured", "sena-addons" ),
					"param_name"  => "featured",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),	
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Title", "sena-addons" ),
					"param_name"  => "title",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
				array(
					"type" => "iconpicker",
					"heading" => esc_html__( "Icon", "sena-addons" ),
					"param_name" => "icon",
					"value" => "",
					"settings" => array(
					  	"emptyIcon" => true,
                        'type' => 'linea',
					  	"iconsPerPage" => 4000,
					),
					"dependency" => array(
					  	"element" => "type",
					  	"value" => "linea",
					),
				),
				array(
					"type"        => "textarea_html",
					"heading"     => esc_html__( "Text", "sena-addons" ),
					"param_name"  => "content",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),				
				array(
					"type" => "iconpicker",
					"heading" => esc_html__( "Currency", "sena-addons" ),
					"param_name" => "currency",
					"value" => "",
					"settings" => array(
					  	"emptyIcon" => true,
                        'type' => 'fontawesome',
					  	"iconsPerPage" => 4000,
					),
					"dependency" => array(
					  	"element" => "type",
					  	"value" => "fontawesome",
					),
				),
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Price", "sena-addons" ),
					"param_name"  => "rate",
					"value"       => "",
					"description" => "Only numbers",
					"admin_label" => true,
			  	),
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Time", "sena-addons" ),
					"param_name"  => "time",
					"value"       => "Month",
					"description" => "",
					"admin_label" => true,
			  	),
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Ribbon", "sena-addons" ),
					"param_name"  => "ribbon",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Button Text", "sena-addons" ),
					"param_name"  => "label",
					"value"       => "Purchase",
					"description" => "",
					"admin_label" => true,
			  	), 
				array(
					'type' => 'vc_link',
					'heading' => __( "Button URL", "sena-addons" ),
					'param_name' => 'url',
					'description' => "",
					"admin_label" => true,
			  	),
			)
		));
	}
    
}

add_shortcode( 'pricing_table', array( 'Sena_Shortcode_Pricing_Tables', 'pricingTable' ) );
add_shortcode( 'plan', 			array( 'Sena_Shortcode_Pricing_Tables', 'plan' ) );
add_action( 'vc_before_init', 	array( 'Sena_Shortcode_Pricing_Tables', 'vc_pricingTable' ) );
add_action( 'vc_before_init', 	array( 'Sena_Shortcode_Pricing_Tables', 'vc_plan' ) );

// Nested shortcodes
add_action( 'vc_before_init', function() {
    
    // Pricing tables extend
	if (class_exists( 'WPBakeryShortCodesContainer' )) {
		class WPBakeryShortCode_pricing_table extends WPBakeryShortCodesContainer {};
	}
	
	if (class_exists( 'WPBakeryShortCode' )) {
		class WPBakeryShortCode_plan extends WPBakeryShortCode {};
	}
    
});
