<?php
// Services ([services])
class Sena_Shortcode_Services {
    
    public static function services( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'mt' => '0px',
			'mb' => '0px',
		), $atts ) );
		
		$mt = intval( $mt );
		$mb = intval( $mb );

		$style = ( $mt > 0 || $mb > 0 ) ? 'style="margin-top: ' . $mt . 'px; margin-bottom: ' . $mb . 'px;"' : '';	
		
		return '<div class="row" ' . $style . '>' . do_shortcode( $content ) . '</div>';
	}
	
	public static function vc_services() {
		vc_map( array(
		   	"name" => esc_html__( "Services", "sena-addons" ),
		   	"base" => "services",
		   	"icon" => 'ti-layout-grid3',
            "description" => esc_html__( "Service grid", "sena-addons" ),
			"as_parent" => array(
            	"only" => "service"
   			),
			"show_settings_on_create" => false,
			"js_view" => "VcColumnView",
			"category" => esc_html__( "Sena", "sena-addons" ),
			"params" => array(
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Margin Top", "sena-addons" ),
					"param_name"  => "mt",
					"value"       => "0px",
					"description" => "",
					"admin_label" => true,
			  	),
			  	array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Margin Bottom", "sena-addons" ),
					"param_name"  => "mb",
					"value"       => "0px",
					"description" => "",
					"admin_label" => true,
			  	),
			)
		));
	}

	// Service ([service])
	public static function service( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'title'         => '',
			'column'        => '1/3',
			'icon'          => '',
			'url'     		=> '',
			'target'  		=> '',
			'class'         => ''
		), $atts ) );
		
		$url = vc_build_link( $url );
		$target = strlen( $url['target'] ) > 0 ? $url['target'] : $target;
		$url = strlen( $url['url'] ) > 0 ? $url['url'] : '';
		
		if ( ! empty( $url ) ) {
			$url = '<a href="' . esc_url( $url ) . '" ' . ( ( $target != '' && $target != '_self' ) ? ' target="' . esc_attr( $target ) . '"' : '' ) . '><div class="arrow icon icon-arrows-right"></div></a>';
		}

		return '<div class="col-md-' . Sena_Shortcodes::getColumnsNumber( $column ) . ' col-sm-12 ' . ( ! empty( $class ) ? ' ' . esc_attr( $class ) : '' ) . '">
					<div class="service-single res-margin">
						<div class="icon ' . esc_html( $icon ) . '"></div>
						<h3>' . esc_html( $title ) . '</h3>
						<p>' . do_shortcode( $content ) . '</p>' . $url . '
					</div>
				</div>';
	}
	
	public static function vc_service() {
		vc_map( array(
		   	"name" => esc_html__( "Service", "sena-addons" ),
		   	"base" => "service",
		   	"icon" => 'ti-layout-grid3',
            "description" => esc_html__( "Service item", "sena-addons" ),
			"as_child" => array(
            	"only" => "services"
   			),
		   	"category" => esc_html__( "Sena", "sena-addons" ),
		   	"params" => array(
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Title", "sena-addons" ),
					"param_name"  => "title",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
				array(
					"type"        => "textarea_html",
					"heading"     => esc_html__( "Text", "sena-addons" ),
					"param_name"  => "content",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
				array(
					"type" => "iconpicker",
					"heading" => esc_html__( "Icon", "sena-addons" ),
					"param_name" => "icon",
					"value" => "",
					"settings" => array(
					  	"emptyIcon" => true,
                        'type' => 'linea',
					  	"iconsPerPage" => 4000,
					),
					"dependency" => array(
					  	"element" => "type",
					  	"value" => "linea",
					),
				),
				array(
					'type' 		  => 'vc_link',
					'heading' 	  => esc_html__( 'URL', 'sena-addons' ),
					'param_name'  => 'url',
					'description' => "",
					"admin_label" => true,
			  	),
				array(
				 	"type" => "dropdown",
				 	"holder" => "div",
				 	"class" => "",
				 	"heading" => esc_html__( "Column", "sena-addons" ),
				 	"param_name" => "column",
				 	"value" => array(   
						"1/2" => '1/2',
						"1/3" => '1/3',
						"1/4" => '1/4',
						"1/6" => '1/6'
					),
					"std" => "1/3",
				 	"description" => "",
					"admin_label" => true,
			  	),
			  	array(
					"type"        => "textfield",
					"heading"     => esc_html__( "CSS Class", "sena-addons" ),
					"param_name"  => "class",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
			)
		));
	}
    
}

add_shortcode( 'services', 		array( 'Sena_Shortcode_Services', 'services' ) );
add_shortcode( 'service', 		array( 'Sena_Shortcode_Services', 'service' ) );
add_action( 'vc_before_init', 	array( 'Sena_Shortcode_Services', 'vc_services' ) );
add_action( 'vc_before_init', 	array( 'Sena_Shortcode_Services', 'vc_service' ) );

// Nested shortcodes
add_action( 'vc_before_init', function() {
    
    // Services extend
	if (class_exists( 'WPBakeryShortCodesContainer' )) {
		class WPBakeryShortCode_services extends WPBakeryShortCodesContainer {};
	}
	
	if (class_exists( 'WPBakeryShortCode' )) {
		class WPBakeryShortCode_service extends WPBakeryShortCode {};
	}
    
});
