<?php
// Info box (Section) ([info_box])
class Sena_Shortcode_Info_Box {
    
    public static function infoBox( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'url' => '',
			'btn' => '',
			'class' => ''
		), $atts ) );
		
		$url = vc_build_link( $url );

		if ( ! empty( $btn ) && strlen( $url['url'] ) > 0 ) {
			$btn = '<a href="' . esc_attr( $url['url'] ) . '" class="btn btn-default btn-rounded">' . esc_html( $btn ) . '</a>';
		}

		return '<div class="info-box row' . ( ! empty( $class ) ? ' ' . esc_attr( $class ) : '' ) . '">
					<div class="' . ( ! empty( $btn ) ? 'col-md-8 text-center-xs res-margin' : 'col-md-12' ) . '">' . do_shortcode( $content ) . '</div>					
					' . ( ! empty( $btn ) ? '<div class="col-md-4 pull-right text-right text-center-xs">'. $btn . '</div>' : '' ) . '
				</div>';
	}
	
	public static function vc_infoBox() {
		vc_map( array(
		   	"name" => esc_html__( "Info Box", "sena-addons" ),
		   	"base" => "info_box",
		   	"icon" => 'ti-info',
            "description" => esc_html__( "Information section", "sena-addons" ),
		   	"category" => esc_html__( "Sena", "sena-addons" ),
		   	"params" => array(
				array(
					"type"        => "textarea_html",
					"heading"     => esc_html__( "Text", "sena-addons" ),
					"param_name"  => "content",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
			  	array(
					'type' => 'vc_link',
					'heading' => esc_html__( "Button URL", "sena-addons" ),
					'param_name' => 'url',
					'description' => "",
					"admin_label" => true,
			  	),
			  	array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Button Label", "sena-addons" ),
					"param_name"  => "btn",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
			  	array(
					"type"        => "textfield",
					"heading"     => esc_html__( "CSS Class", "sena-addons" ),
					"param_name"  => "class",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
			)
		));
	}	
    
}

add_shortcode( 'info_box', 		array( 'Sena_Shortcode_Info_Box', 'infoBox' ) );
add_action( 'vc_before_init', 	array( 'Sena_Shortcode_Info_Box', 'vc_infoBox' ) );

