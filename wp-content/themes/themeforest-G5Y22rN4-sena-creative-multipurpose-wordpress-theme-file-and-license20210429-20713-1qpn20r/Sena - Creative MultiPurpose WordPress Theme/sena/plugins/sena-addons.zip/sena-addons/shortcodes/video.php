<?php
// Video control ([video])
class Sena_Shortcode_Video {
    
    public static function video( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'mt' => '0px',
			'mb' => '0px',
		), $atts ) );
		
		$mt = intval( $mt );
		$mb = intval( $mb );

		$style = ( $mt > 0 || $mb > 0 ) ? 'style="margin-top: ' . $mt . 'px; margin-bottom: ' . $mb . 'px;"' : '';	
		
		return '<div class="video-control" data-hide=".container" ' . $style . '><i class="fas fa-play"></i></div>';
	}
	
	public static function vc_video() {
		vc_map( array(
		   	"name" => esc_html__( "Video Control", "sena-addons" ),
		   	"base" => "video",
		   	"icon" => 'ti-control-play',
            "description" => esc_html__( "Parallax video button", "sena-addons" ),
			"as_parent" => array(
            	"only" => "counter"
   			),
			"show_settings_on_create" => false,
			"js_view" => "VcColumnView",
			"category" => esc_html__( "Sena", "sena-addons" ),
			"params" => array(
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Margin Top", "sena-addons" ),
					"param_name"  => "mt",
					"value"       => "0px",
					"description" => "",
					"admin_label" => true,
			  	),
			  	array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Margin Bottom", "sena-addons" ),
					"param_name"  => "mb",
					"value"       => "0px",
					"description" => "",
					"admin_label" => true,
			  	),
			)
		));
	}
    
}

add_shortcode( 'video', 		array( 'Sena_Shortcode_Video', 'video' ) );
add_action( 'vc_before_init', 	array( 'Sena_Shortcode_Video', 'vc_video' ) );

