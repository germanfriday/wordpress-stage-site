<?php
// Skills ([skills])
class Sena_Shortcode_Skills {
    
    public static function skills( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'mt' => '0px',
			'mb' => '0px',
		), $atts ) );
		
		$mt = intval( $mt );
		$mb = intval( $mb );

		$style = ( $mt > 0 || $mb > 0 ) ? 'style="margin-top: ' . $mt . 'px; margin-bottom: ' . $mb . 'px;"' : '';	
		
		return '<div class="skills" ' . $style . '>' . do_shortcode( $content ) . '</div>';
	}
	
	public static function vc_skills() {
		vc_map( array(
		   	"name" => esc_html__( "Skills", "sena-addons" ),
		   	"base" => "skills",
		   	"icon" => 'ti-align-left',
            "description" => esc_html__( "Progress bars", "sena-addons" ),
			"as_parent" => array(
            	"only" => "bar"
   			),
			"show_settings_on_create" => false,
			"js_view" => "VcColumnView",
			"category" => esc_html__( "Sena", "sena-addons" ),
			"params" => array(
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Margin Top", "sena-addons" ),
					"param_name"  => "mt",
					"value"       => "0px",
					"description" => "",
					"admin_label" => true,
			  	),
			  	array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Margin Bottom", "sena-addons" ),
					"param_name"  => "mb",
					"value"       => "0px",
					"description" => "",
					"admin_label" => true,
			  	),
			)
		));
	}
	
	// Progress bar ([bar])
	public static function bar( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'title'  => '',
			'value'  => 80
		), $atts ) );

		return '<div class="bar"><div class="progress-heading"><p class="progress-title">' . esc_html( $title ) . '</p><div class="progress-value"></div></div><div class="progress"><div class="progress-bar" data-value="' . intval( $value ) . '"></div></div></div>';
	}
	
	public static function vc_bar() {
		vc_map( array(
		   	"name" => esc_html__( "Progress Bar", "sena-addons" ),
		   	"base" => "bar",
		   	"icon" => 'ti-align-left',
            "description" => esc_html__( "Animated progress bar", "sena-addons" ),
			"as_child" => array(
            	"only" => "skills"
   			),
		   	"category" => esc_html__( "Sena", "sena-addons" ),
		   	"params" => array(
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Title", "sena-addons" ),
					"param_name"  => "title",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Value", "sena-addons" ),
					"param_name"  => "value",
					"value"       => "80",
					"description" => "Number between 0 and 100",
					"admin_label" => true,
			  	),
			)
		));
	}
    
}

add_shortcode( 'skills', 		array( 'Sena_Shortcode_Skills', 'skills' ) );
add_shortcode( 'bar', 			array( 'Sena_Shortcode_Skills', 'bar' ) );
add_action( 'vc_before_init', 	array( 'Sena_Shortcode_Skills', 'vc_skills' ) );
add_action( 'vc_before_init', 	array( 'Sena_Shortcode_Skills', 'vc_bar' ) );

// Nested shortcodes
add_action( 'vc_before_init', function() {
    
    // Skills extend
	if (class_exists( 'WPBakeryShortCodesContainer' )) {
		class WPBakeryShortCode_skills extends WPBakeryShortCodesContainer {};
	}
	
	if (class_exists( 'WPBakeryShortCode' )) {
		class WPBakeryShortCode_bar extends WPBakeryShortCode {};
	}
    
});
