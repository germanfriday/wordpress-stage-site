<?php
class Sena_Admin {
	
	// Styles
	public static function sena_styles( ) {
		wp_register_style( 'sena-options', plugins_url( '/styles.css', __FILE__ ) );
	}

	// Scripts
	public static function sena_scripts( ) {
		wp_register_script( 'sena-options', plugins_url( '/functions.js', __FILE__ ), array( ), false, true );
		wp_localize_script( 'sena-options', 'sena_options_lng', array(
			'insert_media' => esc_html__( 'Insert Media', 'sena' )
		) );
	}
	
	// Metabox
	public static function sena_add_metabox( $box ) {
		switch ( $box ) {
			case 'sena_section_type':
				add_meta_box( 'athenastudio_section_type', esc_html__( 'Home Section Type', 'sena-addons' ), array( 'Sena_Section_Type', 'sena_content' ), 'page', 'side' );
				break;
			case 'sena_subtitle':
				add_meta_box( 'athenastudio_subtitle', esc_html__( 'Visual Subtitle', 'sena' ), array( 'Sena_Subtitle', 'sena_content' ), 'page', 'side' );
				add_meta_box( 'athenastudio_subtitle', esc_html__( 'Visual Subtitle', 'sena' ), array( 'Sena_Subtitle', 'sena_content' ), 'portfolio', 'normal' );
				break;
		}
	}
	
	// Action
	public static function sena_add_action( $box ) {
		switch ( $box ) {
			case 'sena_section_type':
				add_action( 'add_meta_boxes', array( 'Sena_Section_Type', 'sena_initialize' ) );
				break;
			case 'sena_subtitle':
				add_action( 'add_meta_boxes', array( 'Sena_Subtitle', 'sena_initialize' ) );
				break;
		}
	}

	// Box
	public static function sena_box( $content ) {
		return '
		<div class="postbox">
			<div class="inside">
				' . $content . '
			</div>
		</div>';
	}

	// Wrapper
	public static function sena_wrap( $title, $content ) {
		return '
		<div class="wrap metabox-holder">
			<h2>' . esc_html( $title ) . '</h2>
			<div style="margin-top: 15px">' . $content . '</div>
		</div>';
	}

	// Message
	public static function sena_message( $content, $type = 'updated' ) {
		return '
		<div class="' . esc_attr( $type ) . ' settings-error" style="margin-top: 15px">
			<p><strong>' . esc_html( $content ) . '</strong></p>
		</div>';
	}

	// Admin menu
	public static function sena_admin_menu( ) {
		add_menu_page( esc_html__( 'Site Sections', 'sena' ), esc_html__( 'Site Sections', 'sena' ), 'manage_options', 'site-sections', array( 'Sena_Admin', 'sena_sections' ), 'dashicons-screenoptions', 101 );
		add_submenu_page( 'edit.php?post_type=portfolio', esc_html__( 'Reorder Items', 'sena' ), esc_html__( 'Reorder Items', 'sena' ), 'manage_options', 'portfolio-reorder', array( 'Sena_Admin', 'sena_portfolio_items' ) );
	}

	// Portolio items order
	public static function sena_portfolio_items( ) {
		global $wpdb;

		wp_enqueue_script( 'sena-options' );
		wp_enqueue_style( 'sena-options' );

		if ( $_POST and isset( $_POST['posts'] ) ) {
			if ( count( $_POST['posts'] ) > 0 ) {
				$internal = 0;
				
				foreach ( $_POST['posts'] as $id ) {
					$internal ++;
					$wpdb->update( $wpdb->posts, array( 'menu_order' => $internal ), array( 'ID' => intval( $id ) ) );
				}
				
				echo self::sena_message( esc_html__( 'Changes saved!', 'sena' ) );
			}
		}

		$rows = get_posts( array(
			'post_type'   		=> 'portfolio',
			'suppress_filters' 	=> 0,
			'orderby'     		=> 'menu_order',
			'order'       		=> 'ASC',
			'numberposts' 		=> '-1',
		) );

		$html = '';
		$empty = true;

		if ( is_array( $rows ) and count( $rows ) > 0 ) {
			$empty = false;
			
			foreach ( $rows as $row ) {
				$title = apply_filters( 'the_title', $row->post_title );
				if ( strlen( $title ) > 28 ) $title = substr( $title, 0, 28 ) . '...';

				$html .= '
				<li>
					<div class="portfolio-item">
						' . get_the_post_thumbnail( $row->ID, array( 200, 200 ) ) . '
						<div class="portfolio-item-title">' . esc_html( $title ) . '</div>
						<input type="hidden" name="posts[]" value="' . esc_attr( $row->ID ) . '">
					</div>
				</li>';
			}
		}

		$html = '
		<ul class="portfolio-items">' . $html . '</ul>
		<div class="portfolio-clr"></div>

		<input type="submit" class="button button-large" value="' . esc_attr__( 'Save Changes', 'sena' ) . '" style="margin: 10px 0 0 10px;">';

		$content = self::sena_box( $html );

		echo '<form action="" method="post">';
		echo self::sena_wrap( esc_html__( 'Reorder Items', 'sena' ), $content );
		echo '</form>';
	}

	// List of pages
	public static function sena_pages_list( $selected = false ) {
		$output = '';
		$pages = get_pages( );
		
		if ( is_array( $pages ) and count( $pages ) > 0 ) {
			foreach ( $pages as $page ) {
				$output .= '<option value="' . esc_attr( $page->post_name ) . '"' . ( ( $selected !== false and $selected == $page->post_name ) ? ' selected="true"' : '' ) . '>' . esc_html( $page->post_title ) . '</option>';
			}
		}

		return $output;
	}

	// Site sections
	public static function sena_sections( ) {
		wp_enqueue_script( 'sena-options' );
		wp_enqueue_style( 'sena-options' );

		$isImport = ( isset( $_REQUEST['do'] ) and $_REQUEST['do'] == 'import' );
		
		if ( $isImport and ! current_user_can( 'import' ) ) {
			unset( $_REQUEST['do'] );
		}
		
		// Normal State
		if ( ! $isImport ) {
			if ( $_POST and isset( $_POST['save'] ) ) {
				if ( update_option( 'sena_sections', json_encode( $_POST['sections'] ) ) ) {
					echo self::sena_message( esc_html__( 'Sections saved!', 'sena' ) );
				} else {
					echo self::sena_message( esc_html__( 'Sections failed to save or not changed.', 'sena' ), 'error' );
				}
			}

			$html = '
			<ul class="site-sections">';

			$layout_types = array(
				'normal'   => esc_html__( 'Normal', 'sena' ),
				'parallax' => esc_html__( 'Section with Parallax Effect', 'sena' ),
				'video'    => esc_html__( 'Section with Video Background', 'sena' )
			);
			
			$sections = array( );
			
			if ( ! empty( get_option( 'sena_sections' ) ) ) {
				$sections = ( array ) json_decode( get_option( 'sena_sections', array( ) ), true );
			}
			
			if ( count( $sections ) > 0 ) {
				$count = count( $sections['page'] );
				for ( $i = 0; $i < $count; $i ++ ) {
					$post = get_page_by_path( $sections['page'][$i] );

					if ( $post !== null ) {
						$post_title = $post->post_title;
					} else {
						$post_title = esc_html__( 'Untitled', 'sena' );
					}

					$html .= '
					<li class="site-section">
						<div class="site-section-remove"><i class="fas fa-times"></i></div>
						<div class="site-section-title">
							<span class="site-section-title-text">' . esc_html( $post_title ) . '</span>
							<span class="site-section-title-type">' . esc_html( ( ! empty( $layout_types[$sections['layout'][$i]] ) ? $layout_types[$sections['layout'][$i]] : '-' ) ) . '</span>
						</div>
						<div class="site-section-area">
							<div>
								<p><strong>' . __( 'Layout Type', 'sena' ) . '</strong></p>
								<select name="sections[layout][]" class="section-layout-type">
									<option value="normal"' . ( $sections['layout'][$i] == 'normal' ? ' selected="selected"' : '' ) . '>' . __( 'Normal', 'sena' ) . '</option>
									<option value="parallax"' . ( $sections['layout'][$i] == 'parallax' ? ' selected="selected"' : '' ) . '>' . __( 'Section with Parallax Effect', 'sena' ) . '</option>
									<option value="video"' . ( $sections['layout'][$i] == 'video' ? ' selected="selected"' : '' ) . '>' . __( 'Section with Video Background', 'sena' ) . '</option>
								</select>
							</div>
							<div style="display: none">
								<p><strong>' . __( 'Section Content', 'sena' ) . '</strong></p>
								<textarea class="input-large site-sections-content" name="sections[content][]" rows="4"></textarea>
							</div>
							<div data-layout-type="normal parallax video">
								<p><strong>' . __( 'Section Content', 'sena' ) . '</strong></p>
								<select name="sections[page][]" class="section-title">
									<option value="">&mdash; ' . esc_html__( 'Select a page', 'sena' ) . ' &mdash;</option>
									' . self::sena_pages_list( ( ! empty( $sections['page'][$i] ) ? esc_html( $sections['page'][$i] ) : false ) ) . '
								</select>
							</div>
							<div data-layout-type="normal">
								<p><strong>' . __( 'Background Color', 'sena' ) . '</strong></p>
								<select name="sections[background][]" class="section-background">
									<option value=""' . ( $sections['background'][$i] != 'grey' ? ' selected="selected"' : '' ) . '>' . __( 'Default', 'sena' ) . '</option>
									<option value="grey"' . ( $sections['background'][$i] == 'grey' ? ' selected="selected"' : '' ) . '>' . __( 'Grey', 'sena' ) . '</option>
									<option value="dark"' . ( $sections['background'][$i] == 'dark' ? ' selected="selected"' : '' ) . '>' . __( 'Dark', 'sena' ) . '</option>
								</select>
							</div>
							<div data-layout-type="parallax">
								<p><strong>' . esc_html__( 'Background Image', 'sena' ) . '</strong></p>
								<input type="text" class="input-large" name="sections[image][]" value="' . esc_url( $sections['image'][$i] ) . '" />
								<input type="button" class="button meta-item-upload" value="' . esc_attr__( 'Choose or Upload an Image', 'sena' ) . '" style="margin: -1px 0 0 5px; font-size: 12px">
							</div>
							<div data-layout-type="video">
								<p><strong>' . esc_html__( 'Video Start at', 'sena' ) . '</strong></p>
								<input type="text" class="input-small" name="sections[video-start][]" value="' . intval( $sections['video-start'][$i] ) . '" /> ' . __( 'seconds', 'sena' ) . '

								<p><strong>' . esc_html__( 'YouTube Video ID', 'sena' ) . '</strong></p>
								<input type="text" class="input-large" name="sections[video][]" value="' . esc_attr( $sections['video'][$i] ) . '" />
								<p>' . esc_html__( 'Example,', 'sena' ) . ' https://www.youtube.com/watch?v=<strong>kn-1D5z3-Cs</strong></p>
							</div>
							<div data-layout-type="parallax video">
								<p><strong>' . __( 'Overlay', 'sena' ) . '</strong></p>
								<select name="sections[overlay][]">
									<option value="disabled"' . ( $sections['overlay'][$i] == 'disabled' ? ' selected="selected"' : '' ) . '>' . __( 'Disabled', 'sena' ) . '</option>
									<option value="default"' . ( $sections['overlay'][$i] == 'default' ? ' selected="selected"' : '' ) . '>' . __( 'Default', 'sena' ) . '</option>
									<option value="primary"' . ( $sections['overlay'][$i] == 'primary' ? ' selected="selected"' : '' ) . '>' . __( 'Primary Color', 'sena' ) . '</option>
								</select>
							</div>
						</div>
					</li>';
				}

				$html = '
				<div style="margin-bottom: 20px;">
					<a href="#" class="button button-large add-new-section" style="font-size: 10px;" title="' . esc_html__( 'New Item', 'sena' ) . '"><i class="fas fa-plus"></i></a>&nbsp;
					<input type="submit" class="button button-large button-primary" value="' . esc_attr__( 'Save Changes', 'sena' ) . '" />
					' . ( current_user_can( 'import' ) ? '
					<div style="float: right;">
						<a href="?page=site-sections&do=import" class="button button-large">' . esc_html__( 'Import & Export Sections', 'sena' ) . '</a>
					</div>
					<div style="clear:both"></div>' : '' ) . '
				</div>' . $html;
			}

			$html .= '
			</ul>

			<div>
				<a href="#" class="button button-large add-new-section" style="font-size: 10px;" title="' . esc_attr__( 'New Item', 'sena' ) . '"><i class="fas fa-plus"></i></a>&nbsp;
				<input type="submit" class="button button-large button-primary" value="' . esc_attr__( 'Save Changes', 'sena' ) . '" />';

			if ( count( $sections ) == 0 and current_user_can( 'import' ) ) {
				$html .= '
				<div style="float: right;">
					<a href="?page=site-sections&do=import" class="button button-large">' . esc_html__( 'Import & Export Sections', 'sena' ) . '</a>
				</div>
				<div style="clear:both"></div>';
			}

			$html .= '</div>';

			$content = self::sena_box( $html );

			echo '<form action="" method="post"><input type="hidden" name="save" value="true">';
			echo self::sena_wrap( esc_html__( 'Site Sections', 'sena' ), $content );
			echo '</form>

			<ul style="display:none">
				<li class="site-section" id="new-section-mockup">
					<div class="site-section-remove"><i class="fas fa-times"></i></div>
					<div class="site-section-title">
						<span class="site-section-title-text">' . esc_html__( 'Untitled', 'sena' ) . '</span>
						<span class="site-section-title-type">' . esc_html__( 'Normal', 'sena' ) . '</span>
					</div>
					<div class="site-section-area opened">
						<div>
							<p><strong>' . esc_html__( 'Layout Type', 'sena' ) . '</strong></p>
							<select name="sections[layout][]" class="section-layout-type">
								<option value="normal" selected="selected">' . esc_html__( 'Normal', 'sena' ) . '</option>
								<option value="parallax">' . esc_html__( 'Section with Parallax Effect', 'sena' ) . '</option>
								<option value="video">' . esc_html__( 'Section with Video Background', 'sena' ) . '</option>
							</select>
						</div>
						<div style="display: none">
							<p><strong>' . esc_html__( 'Section Content', 'sena' ) . '</strong></p>
							<textarea class="input-large site-sections-content" name="sections[content][]" rows="4"></textarea>
						</div>
						<div data-layout-type="normal parallax video">
							<p><strong>' . esc_html__( 'Section Content', 'sena' ) . '</strong></p>
							<select name="sections[page][]" class="section-title">
								<option value="">&mdash; ' . esc_html__( 'Select a page', 'sena' ) . ' &mdash;</option>
								' . self::sena_pages_list( false ) . '
							</select>
						</div>
						<div data-layout-type="normal">
							<p><strong>' . esc_html__( 'Background Color', 'sena' ) . '</strong></p>
							<select name="sections[background][]" class="section-background">
								<option value="">' . esc_html__( 'Default', 'sena' ) . '</option>
								<option value="grey">' . esc_html__( 'Grey', 'sena' ) . '</option>
								<option value="dark">' . esc_html__( 'Dark', 'sena' ) . '</option>
							</select>
						</div>
						<div data-layout-type="parallax" style="display: none">
							<p><strong>' . esc_html__( 'Background Image', 'sena' ) . '</strong></p>
							<input type="text" class="input-large" name="sections[image][]" value="" />
							<input type="button" class="button meta-item-upload" value="' . esc_attr__( 'Choose or Upload an Image', 'sena' ) . '" style="margin: -1px 0 0 5px; font-size: 12px">
						</div>
						<div data-layout-type="video" style="display: none">
							<p><strong>' . esc_html__( 'Video Start at', 'sena' ) . '</strong></p>
							<input type="text" class="input-small" name="sections[video-start][]" value="0" /> ' . __( 'seconds', 'sena' ) . '

							<p><strong>' . esc_html__( 'YouTube Video ID', 'sena' ) . '</strong></p>
							<input type="text" class="input-large" name="sections[video][]" value="" />
							<p>' . esc_html__( 'Example,', 'sena' ) . ' https://www.youtube.com/watch?v=<strong>kn-1D5z3-Cs</strong></p>
						</div>
						<div data-layout-type="parallax video" style="display: none">
							<p><strong>' . esc_html__( 'Overlay', 'sena' ) . '</strong></p>
							<select name="sections[overlay][]">
								<option value="disabled" selected="selected">' . esc_html__( 'Disabled', 'sena' ) . '</option>
								<option value="default">' . esc_html__( 'Default', 'sena' ) . '</option>
								<option value="primary">' . esc_html__( 'Primary Color', 'sena' ) . '</option>
							</select>
						</div>
					</div>
				</li>
			</ul>';
		} 
		
		// Import and export sections
		else {
			if ( isset( $_POST['upload'] ) ) {
				if ( self::sena_do_import( 'import' ) ) {
					echo self::sena_message( esc_html__( 'Sections updated!', 'sena' ) . '<br><br><a href="?page=site-sections">' . __( 'Return back', 'sena' ) . '</a>' );
				}
			}

			$html = '
			<form action="" method="post" enctype="multipart/form-data">
				<input type="hidden" name="page" value="site-sections">
				<input type="hidden" name="do" value="import">
				<input type="hidden" name="upload" value="true">

				<h3>' . esc_html__( 'Import Sections', 'sena' ) . '</h3>
				<p>' . esc_html__( 'Choose a JSON (.json) file to upload, then click Upload file and import.', 'sena' ) . '</p>
				<p><strong>' . esc_html__( 'Warning:', 'sena' ) . ' ' . esc_html__( 'This action will overwrite all existing sections.', 'sena' ) . '</strong></p>
				<div><input name="import" size="25" type="file"></div>
				<div style="margin-top: 15px;">
					<input type="submit" class="button button-large button-primary" value="' . esc_attr__( 'Upload File and Import', 'sena' ) . '">
				</div>
			</form>';

			$sections = ( array ) json_decode( get_option( 'sena_sections', array( ) ), true );

			if ( count( $sections ) > 0 ) {
				$html .= '
				<div style="height: 30px;"></div>

				<h3>' . esc_html__( 'Export Sections', 'sena' ) . '</h3>
				<p>' . esc_html__( 'When you click the button below will create an JSON file for you to save to your computer.', 'sena' ) . '</p>
				<p>' . esc_html__( 'Once you\'ve saved the download file, you can use the Import function in another site to import the sections from this site.', 'sena' ) . '</p>
				<div style="margin-top: 20px;">
					<a href="' . plugins_url( 'inc/ajax.php?action=export-sections', dirname(__FILE__) ) . '" class="button button-large button-primary">' . __( 'Download Export File', 'sena' ) . '</a>
				</div>';
			}

			echo self::sena_wrap( esc_html__( 'Import &amp; Export Sections', 'sena' ), self::sena_box( $html ) );
		}
	}

	// Import sections
	public static function sena_do_import( $field ) {
		wp_enqueue_script( 'sena-options' );
		wp_enqueue_style( 'sena-options' );

		$url = wp_nonce_url( 'themes.php?page=site-sections&do=import', 'sena-sections-import' );
		$fields = array( 'upload' );
		
		if ( false === ( $creds = request_filesystem_credentials( $url, '', false, false, $fields ) ) ) {
			return;
		}
		
		if ( ! WP_Filesystem( $creds ) ) {
			request_filesystem_credentials( $url, '', true, false, $fields );
			return;
		}

		$file = &$_FILES[$field];
		
		if ( ! empty( $file['tmp_name'] ) and intval( $file['size'] ) > 0 and intval( $file['error'] ) === 0 ) {
			global $wp_filesystem;
			$content = $wp_filesystem->get_contents( $file['tmp_name'] );
			
			if ( $content !== false ) {
				$try = json_decode( $content, true );
				
				if ( is_array( $try ) and count( $try ) > 0 ) {
					if ( update_option( 'sena_sections', json_encode( $try ) ) ) {
						return true;
					} else {
						echo self::sena_message( esc_html__( 'Error: Problem with saving changes.', 'sena' ), 'error' );
					}
				} else {
					echo self::sena_message( esc_html__( 'Error: Not valid file format.', 'sena' ), 'error' );
				}
			} else {
				echo self::sena_message( esc_html__( 'Error: Problem when opening a file.', 'sena' ), 'error' );
			}
		}
		
		return false;
	}
	
	// One click demo import
	public static function sena_one_click_import( $file ) {
		wp_enqueue_script( 'sena-options' );
		wp_enqueue_style( 'sena-options' );
		
		$content = wp_remote_get( $file );
			
		if ( ! is_wp_error( $content ) ) {
			$body = wp_remote_retrieve_body( $content );
			
			$try = json_decode( $body, true );			
			
			if ( is_array( $try ) and count( $try ) > 0 ) {
				if ( update_option( 'sena_sections', json_encode( $try ) ) ) {
					return true;
				} else {
					echo self::sena_message( esc_html__( 'Error: Problem with saving changes.', 'sena' ), 'error' );
				}
			} else {
				echo self::sena_message( esc_html__( 'Error: Not valid file format.', 'sena' ), 'error' );
			}
		} else {
			echo self::sena_message( esc_html__( 'Error: Problem when opening a file.', 'sena' ), 'error' );
		}
		
		return false;
	}
	
}

// Admin menu
add_action( 'admin_menu', array( 'Sena_Admin', 'sena_admin_menu' ) );

// Styles and scripts
add_action( 'admin_enqueue_scripts', array( 'Sena_Admin', 'sena_styles' ) );
add_action( 'admin_enqueue_scripts', array( 'Sena_Admin', 'sena_scripts' ) );
