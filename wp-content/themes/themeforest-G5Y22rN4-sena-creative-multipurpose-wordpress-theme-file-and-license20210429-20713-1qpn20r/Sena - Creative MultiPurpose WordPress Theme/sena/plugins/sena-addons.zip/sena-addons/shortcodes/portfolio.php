<?php
// Portfolio ([portfolio])
class Sena_Shortcode_Portfolio {
    
    public static function portfolio( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'order'              => 'menu_order',
			'filters'            => 'true',
			'limit'              => -1,
			'terms'              => '',
            'size_large'         => 4,
            'size_medium'        => 4,
            'size_small'         => 4,
            'size_extra_small'   => 2
		), $atts ) );

		$filters_html = '';
		$limit = intval( $limit );
        $size_large = intval( $size_large );
        $size_medium = intval( $size_medium );
        $size_small = intval( $size_small );
        $size_extra_small = intval( $size_extra_small );

		if ( $filters == 'true' ) {
			$categories = get_terms(array(
							'taxonomy' 		=> 'portfolio-category',							
							'orderby' 		=> 'count', 
							'order' 		=> 'DESC',
							'hide_empty' 	=> true
						  ));			
			
			if ( count( $categories ) > 0 ) {
				$filters_html = '<span data-filter="*" class="active">' . esc_html__( 'All', 'sena-addons' ) . '</span>';
				
				foreach ( $categories as $row ) {
					$filters_html .= '<span data-filter=".' . esc_attr( $row->slug ) . '">' . esc_html( $row->name ) . '</span>';
				}
			}
		}

		$query = array(
			'post_type'   		=> 'portfolio',
			'suppress_filters' 	=> 0,
			'numberposts' 		=> $limit,
			'order'       		=> ( ( $order == 'date' or $order == 'modified' or $order == 'rand' ) ? 'DESC' : 'ASC' ),
			'orderby'    		=> $order
		);

		if ( ! empty( $terms ) ) {
			$terms_arr = explode( ',', $terms );
			$terms_query = array( );

			if ( is_array( $terms_arr ) and count( $terms_arr ) > 0 ) {
				foreach ( $terms_arr as $term ) {
					$terms_query[] = trim( esc_sql( $term ) );
				}

				$query['tax_query'] = array(
					array(
						'taxonomy' => 'portfolio-category',
						'field'    => 'slug',
						'terms'    => $terms_query                        
					)
				);
			}
		}

		$rows = get_posts( $query );
		$output = $projects = '';

		if ( count( $rows ) > 0 ) {
			$i = 0;
			
			foreach ( $rows as $row ) {
				$i ++;
				$info = wp_get_object_terms( $row->ID, 'portfolio-category' );
				$category = array( );
				$filter = '';

				foreach( $info as $item ) {
					$category[] = $item->name;
					$filter .= $item->slug . ' ';
				}

				$category = implode( ', ', $category );
				$filter = rtrim( $filter );
				unset( $info );

				$thumb = wp_get_attachment_image_src( get_post_thumbnail_id( $row->ID ), 'full' );
				$title = apply_filters( 'the_title', $row->post_title );
				$link = get_permalink( $row->ID );
				
				$projects .= '
				<div>
					<div class="portfolio-item' . ( ! empty( $filter ) ? ' ' . esc_attr( $filter ) : '' ) . '">
						<div><img src="' . $thumb[0] . '" alt="' . esc_attr( $title ) . '"></div>
						<div class="img-overlay valign">
							<div class="overlay-info full-width vertical-center"><h6>' . esc_html( $title ) . '</h6><p>' . esc_html( $category ) . '</p></div>
							<div><a href="' . esc_url( $link ) . '" data-rel="' . esc_attr( $row->post_name ) . '"></a></div>
						</div>
					</div>
				</div>';
			}

			if ( $filters == 'true' and ! empty( $filters_html ) ) {
				$output = '<div class="row"><div class="portfolio-filters text-center col-sm-12">' . $filters_html . '</div></div>';
			}

			$output .= '</div></div></div></div></div><div class="container-fluid"><div class="row portfolio-items clearfix" data-on-line-lg="' . $size_large . '" data-on-line-md="' . $size_medium . '" data-on-line-sm="' . $size_small . '" data-on-line-xs="' . $size_extra_small . '">' . $projects . '</div><div><div><div><div>';
		}

		return $output;
	}
	
	public static function vc_portfolio() {
		vc_map( array(
		   	"name" => esc_html__( "Portfolio", "sena-addons" ),
		   	"base" => "portfolio",
		   	"icon" => 'ti-briefcase',
            "description" => esc_html__( "Recent projects", "sena-addons" ),
		   	"category" => esc_html__( "Sena", "sena-addons" ),
		   	"params" => array(
				array(
                    "group"       => "General",
				 	"type"        => "dropdown",
				 	"holder"      => "div",
				 	"class"       => "",
				 	"heading"     => esc_html__( "Order By", "sena-addons" ),
				 	"param_name"  => "order",
				 	"value"       => array(   
						"Default"     => 'menu_order',
						"ID"          => 'id',
						"Title"       => 'title',
						"Date"        => 'date',
						"Modified"    => 'modified',
						"Random"      => 'rand'
					),
					"std"         => "menu_order",
				 	"description" => "",
					"admin_label" => true,
			  	),
				array(
                    "group"       => "General",
					"type"        => "checkbox",
					"heading"     => esc_html__( "Filters", "sena-addons" ),
					"param_name"  => "filters",
					"value"       => "",
					"std"         => "true",
					"description" => "",
					"admin_label" => true,
			  	),
				array(
                    "group"       => "General",
					"type"        => "textfield",
					"heading"     => esc_html__( "Limit", "sena-addons" ),
					"param_name"  => "limit",
					"value"       => "-1",
					"description" => "",
					"admin_label" => true,
			  	),
				array(
                    "group"       => "General",
					"type"        => "textfield",
					"heading"     => esc_html__( "Terms", "sena-addons" ),
					"param_name"  => "terms",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
                array(
                    "group"       => "Column Size",
					"type"        => "textfield",
					"heading"     => esc_html__( "Desktop", "sena-addons" ),
					"param_name"  => "size_large",
					"value"       => "4",
					"description" => "",
					"admin_label" => true,
			  	),
                array(
                    "group"       => "Column Size",
					"type"        => "textfield",
					"heading"     => esc_html__( "Laptop", "sena-addons" ),
					"param_name"  => "size_medium",
					"value"       => "4",
					"description" => "",
					"admin_label" => true,
			  	),
                array(
                    "group"       => "Column Size",
					"type"        => "textfield",
					"heading"     => esc_html__( "Tablet", "sena-addons" ),
					"param_name"  => "size_small",
					"value"       => "4",
					"description" => "",
					"admin_label" => true,
			  	),
                array(
                    "group"       => "Column Size",
					"type"        => "textfield",
					"heading"     => esc_html__( "Phone", "sena-addons" ),
					"param_name"  => "size_extra_small",
					"value"       => "2",
					"description" => "",
					"admin_label" => true,
			  	),
			)
		));
	}
	
	// Project details ([details])
	public static function details( $atts, $content = null ) {
		extract( shortcode_atts( array(
		), $atts ) );

		$content = preg_replace( '/<ul/', '<ul class="fa-ul details"', $content );
		$content = preg_replace( '/<li>/', '<li><i class="fa-li fas fa-angle-right colored"></i> ', $content );

		return do_shortcode( $content );
	}
	
	public static function vc_details() {
		vc_map( array(
		   	"name" => esc_html__("Project Details", "sena-addons"),
		   	"base" => "details",
		   	"icon" => 'ti-book',
            "description" => esc_html__( "Item info", "sena-addons" ),
			"category" => esc_html__("Sena", "sena-addons"),
		   	"params" => array(
				array(
					"type"        => "textarea_html",
					"heading"     => esc_html__( "Text", "sena-addons" ),
					"param_name"  => "content",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
				),
			)
		));
	}
    
}

add_shortcode( 'portfolio', 	array( 'Sena_Shortcode_Portfolio', 'portfolio' ) );
add_shortcode( 'details', 		array( 'Sena_Shortcode_Portfolio', 'details' ) );
add_action( 'vc_before_init', 	array( 'Sena_Shortcode_Portfolio', 'vc_portfolio' ) );
add_action( 'vc_before_init', 	array( 'Sena_Shortcode_Portfolio', 'vc_details' ) );

