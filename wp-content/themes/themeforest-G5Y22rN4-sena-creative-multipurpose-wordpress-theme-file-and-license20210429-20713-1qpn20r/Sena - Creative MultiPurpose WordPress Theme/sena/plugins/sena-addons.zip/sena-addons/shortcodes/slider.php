<?php
// Slider ([slider])
class Sena_Shortcode_Slider {
    
    public static function slider( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'slide' => '',
			'class'  => ''
		), $atts ) );
		
		$output = '<div class="image-slider' . ( ! empty( $class ) ? ' ' . trim( esc_attr( $class ) ) : '' ) . '">';

		$ids = explode(',', $slide);

		foreach ( $ids as $id ) {
			$output .= '<div><img src="' . wp_get_attachment_url( $id ) . '" class="img-responsive img-rounded" alt=""></div>';
		}

		$output .= '<div class="arrows"><a class="arrow left"><i class="fas fa-chevron-left"></i></a><a class="arrow right"><i class="fas fa-chevron-right"></i></a></div></div>';
		
		return $output;
	}
	
	public static function vc_slider() {
		vc_map( array(
		   	"name" => esc_html__( "Image Slider", "sena-addons" ),
		   	"base" => "slider",
		   	"icon" => 'ti-layout-slider-alt',
            "description" => esc_html__( "Project slideshow", "sena-addons" ),
		   	"category" => esc_html__( "Sena", "sena-addons" ),
		   	"params" => array(
				array(
					"type"        => "attach_images",
					"heading"     => esc_html__( "Images", "sena-addons" ),
					"param_name"  => "slide",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
			  	array(
					"type"        => "textfield",
					"heading"     => esc_html__( "CSS Class", "sena-addons" ),
					"param_name"  => "class",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
			)
		));
	}
    
}

add_shortcode( 'slider', 		array( 'Sena_Shortcode_Slider', 'slider' ) );
add_action( 'vc_before_init', 	array( 'Sena_Shortcode_Slider', 'vc_slider' ) );

