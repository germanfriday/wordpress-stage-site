<?php
// Single Image (Intro) ([single_image])
class Sena_Shortcode_Single_Image {
    
    public static function singleImage( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'bg_image' => ''
		), $atts ) );
        
        $image = '';
        
        if ( ! empty( $bg_image ) ) {
             $image = wp_get_attachment_url( $bg_image );
        }
        
        return  '<div class="image" data-source="' . $image . '"></div>
                 <div class="row">
                    <div class="col-md-12 text-center">
                        <div class="caption">'. do_shortcode( $content ) . '</div>
                    </div>
                 </div>';
	}
	
	public static function vc_singleImage() {
		vc_map( array(
		   	"name" => esc_html__( "Single Image", "sena-addons" ),
		   	"base" => "single_image",
		   	"icon" => 'ti-image',
            "description" => esc_html__( "Intro image background", "sena-addons" ),
		   	"category" => esc_html__( "Sena", "sena-addons" ),
		   	"params" => array(
                array(
					"type"        => "attach_image",
					"heading"     => esc_html__( "Background Image", "sena-addons" ),
					"param_name"  => "bg_image",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
				array(
					"type"        => "textarea_html",
					"heading"     => esc_html__( "Content", "sena-addons" ),
					"param_name"  => "content",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
			)
		));
	}
    
}

add_shortcode( 'single_image', 	array( 'Sena_Shortcode_Single_Image', 'singleImage' ) );
add_action( 'vc_before_init', 	array( 'Sena_Shortcode_Single_Image', 'vc_singleImage' ) );

