<?php
// Clients ([clients])
class Sena_Shortcode_Clients {
	
	public static function clients( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'mt' => '0px',
			'mb' => '0px',
		), $atts ) );
		
		$mt = intval( $mt );
		$mb = intval( $mb );

		$style = ( $mt > 0 || $mb > 0 ) ? 'style="margin-top: ' . $mt . 'px; margin-bottom: ' . $mb . 'px;"' : '';	
		
		return '<div class="clients-slider owl-carousel owl-theme" ' . $style . '>' . do_shortcode( $content ) . '</div>';
	}
	
	public static function vc_clients() {
		vc_map( array(
		   	"name" => esc_html__( "Clients", "sena-addons" ),
		   	"base" => "clients",
		   	"icon" => 'ti-id-badge',
            "description" => esc_html__( "Client logos", "sena-addons" ),
			"as_parent" => array(
            	"only" => "client"
   			),
			"show_settings_on_create" => false,
			"js_view" => "VcColumnView",
			"category" => esc_html__( "Sena", "sena-addons" ),
			"params" => array(
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Margin Top", "sena-addons" ),
					"param_name"  => "mt",
					"value"       => "0px",
					"description" => "",
					"admin_label" => true,
			  	),
			  	array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Margin Bottom", "sena-addons" ),
					"param_name"  => "mb",
					"value"       => "0px",
					"description" => "",
					"admin_label" => true,
			  	),
			)
		));
	}

	// Client ([client])
	public static function client( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'image'         => '',
			'website'		=> ''
		), $atts ) );
		
		// Image
		$img = '';
        
        if ( ! empty( $image ) ) {
             $img = wp_get_attachment_url( $image );
        }
		
		// Website
		$website = vc_build_link( $website );
		
		return '<div class="client">'. ( strlen( $website['url'] ) > 0 ? '<a href="' . esc_url( $website['url'] ) . '" ' . ( strlen( $website['target'] ) > 0 ? 'target="' . $website['target'] . '"' : '' ) . '>' : '' ) . '<img src="' . $img . '" alt="' . do_shortcode( $content ) . '">'. ( strlen( $website['url'] ) > 0 ? '</a>' : '' ) . '</div>';
	}
	
	public static function vc_client() {
		vc_map( array(
		   	"name" => esc_html__( "Client", "sena-addons" ),
		   	"base" => "client",
		   	"icon" => 'ti-id-badge',
			"as_child" => array(
            	"only" => "clients"
   			),
		   	"category" => esc_html__( "Sena", "sena-addons" ),
		   	"params" => array(
				array(
					"type"        => "attach_image",
					"heading"     => esc_html__( "Image", "sena-addons" ),
					"param_name"  => "image",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Name", "sena-addons" ),
					"param_name"  => "content",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
				array(
					'type' 		  => 'vc_link',
					'heading' 	  => esc_html__( "Website URL", "sena-addons" ),
					'param_name'  => 'website',
					'description' => "",
					"admin_label" => true,
			  	),
			)
		));
	}
    
}

add_shortcode( 'clients', 			array( 'Sena_Shortcode_Clients', 'clients' ) );
add_shortcode( 'client', 			array( 'Sena_Shortcode_Clients', 'client' ) );
add_action( 'vc_before_init', 		array( 'Sena_Shortcode_Clients', 'vc_clients' ) );
add_action( 'vc_before_init', 		array( 'Sena_Shortcode_Clients', 'vc_client' ) );

// Nested shortcodes
add_action( 'vc_before_init', function() {
    
    // Features extend
	if (class_exists( 'WPBakeryShortCodesContainer' )) {
		class WPBakeryShortCode_clients extends WPBakeryShortCodesContainer {};
	}
	
	if (class_exists( 'WPBakeryShortCode' )) {
		class WPBakeryShortCode_client extends WPBakeryShortCode {};
	}
    
});

