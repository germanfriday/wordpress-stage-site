<?php
// Contact form ([contact_form])
class Sena_Shortcode_Contact_Form {
    
    public static function contactForm( $atts, $content = null ) {
		return '<div id="sena-contact-form" class="contact-form field-action" data-url="' . esc_url( plugins_url( 'inc/ajax.php', dirname(__FILE__) ) ) . '">
					<div class="contact-form-holder">
						<div class="field">
							<input type="text" name="name" class="field-name" placeholder="' . esc_attr__( 'Name', 'sena-addons' ) . '">
						</div>			
						<div class="field">
							<input type="email" name="email" class="field-email" placeholder="' . esc_attr__( 'Email', 'sena-addons' ) . '">
						</div>
						<div class="field">
							<input type="text" name="phone" class="field-phone" placeholder="' . esc_attr__( 'Phone', 'sena-addons' ) . '">
						</div>
						<div class="field">
							<textarea name="message" class="field-message" placeholder="' . esc_attr__( 'Message', 'sena-addons' ) . '"></textarea>
						</div>					
						<div>
							<button type="submit" class="btn btn-default" id="contact-submit"><i class="fas fa-paper-plane"></i> ' . esc_attr__( 'Send Message', 'sena-addons' ) . '</button>
						</div>
					</div>
				</div>
				<div class="contact-form-result"><p>' . do_shortcode( $content ) . '</p></div>';
	}
	
	public static function vc_contactForm() {
		vc_map( array(
		   	"name" => esc_html__( "Contact Form", "sena-addons" ),
		   	"base" => "contact_form",
		   	"icon" => 'ti-email',
            "description" => esc_html__( "Get in touch", "sena-addons" ),
		   	"category" => esc_html__( "Sena", "sena-addons" ),
		   	"params" => array(
				array(
					"type"        => "textarea_html",
					"heading"     => esc_html__( "Form Result Text", "sena-addons" ),
					"param_name"  => "content",
					"value"       => "<h3>Thank You for the Email!</h3><p>Your message has already arrived! We'll contact you shortly.</p><h5>Good day.</h5>",
					"description" => "",
					"admin_label" => true,
			  	),
			)
		));
	}
    
}

add_shortcode( 'contact_form', 	array( 'Sena_Shortcode_Contact_Form', 'contactForm' ) );
add_action( 'vc_before_init', 	array( 'Sena_Shortcode_Contact_Form', 'vc_contactForm' ) );

