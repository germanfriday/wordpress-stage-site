<?php
// Accordion ([accordions])
class Sena_Shortcode_Accordions {
    
    static $accordionsCounters;
	static $accordionCounters;
    
    public static function accordions( $atts, $content = null ) {
		self::$accordionsCounters = ( self::$accordionsCounters > 0 ) ? ( int ) self::$accordionsCounters : 0;
		self::$accordionsCounters ++;

		extract( shortcode_atts( array(
			'mt' => '0px',
			'mb' => '0px',
		), $atts ) );
		
		$mt = intval( $mt );
		$mb = intval( $mb );

		$style = ( $mt > 0 || $mb > 0 ) ? 'style="margin-top: ' . $mt . 'px; margin-bottom: ' . $mb . 'px;"' : '';		
		
		$content = do_shortcode( $content );
		
		return '<div class="faq-support"><div class="panel-group" id="accordion' . self::$accordionsCounters . '" ' . $style . '>' . $content . '</div></div>';
	}
	
	public static function vc_accordions() {
		vc_map( array(
		   	"name" => esc_html__( "Accordion", "sena-addons" ),
		   	"base" => "accordions",
		   	"icon" => 'ti-layout-accordion-separated',
            'description' => esc_html__( "Accordion section", "sena-addons" ),
			"as_parent" => array(
            	"only" => "accordion"
   			),
			"show_settings_on_create" => false,
			"js_view" => "VcColumnView",
			"category" => esc_html__( "Sena", "sena-addons" ),
			"params" => array(
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Margin Top", "sena-addons" ),
					"param_name"  => "mt",
					"value"       => "0px",
					"description" => "",
					"admin_label" => true,
			  	),
			  	array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Margin Bottom", "sena-addons" ),
					"param_name"  => "mb",
					"value"       => "0px",
					"description" => "",
					"admin_label" => true,
			  	),
			)
		));
	}

	// Accordion tab ([accordion])
	public static function accordion( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'title'  => '',
			'opened' => 'no'
		), $atts ) );

		self::$accordionCounters = ( self::$accordionCounters > 0 ) ? ( int ) self::$accordionCounters : 0;
		self::$accordionCounters ++;
		
		$cls = ( $opened == 'true' ? '' : 'class="collapsed"' );
		
		return '<div class="panel">
					<div class="panel-heading"><h4 class="panel-title"><a href="#collapse' . self::$accordionCounters . '" data-toggle="collapse" data-parent="#accordion' . self::$accordionsCounters . '" ' . $cls . '>' . esc_html( $title ) . '</a></h4></div>
					<div id="collapse' . self::$accordionCounters . '" class="panel-collapse collapse ' . ( $opened == 'true' ? 'in' : '' ) . '">
						<div class="panel-body"><p>' . do_shortcode( $content ) . '</p></div>
					</div>
				</div>';
	}
	
	public static function vc_accordion() {
		vc_map( array(
		   	"name" => esc_html__( "Accordion Tab", "sena-addons" ),
		   	"base" => "accordion",
		   	"icon" => 'ti-layout-accordion-separated',
			"as_child" => array(
            	"only" => "accordions"
   			),
		   	"category" => esc_html__( "Sena", "sena-addons" ),
		   	"params" => array(
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Title", "sena-addons" ),
					"param_name"  => "title",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
				array(
					"type"        => "textarea_html",
					"heading"     => esc_html__( "Text", "sena-addons" ),
					"param_name"  => "content",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
				array(
					"type"        => "checkbox",
					"heading"     => esc_html__( "Opened", "sena-addons" ),
					"param_name"  => "opened",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),		  	
			)
		));
	}
    
}

add_shortcode( 'accordions', 	array( 'Sena_Shortcode_Accordions', 'accordions' ) );
add_shortcode( 'accordion', 	array( 'Sena_Shortcode_Accordions', 'accordion' ) );
add_action( 'vc_before_init', 	array( 'Sena_Shortcode_Accordions', 'vc_accordions' ) );
add_action( 'vc_before_init', 	array( 'Sena_Shortcode_Accordions', 'vc_accordion' ) );

// Nested shortcodes
add_action( 'vc_before_init', function() {
    
    // Accordions extend
	if (class_exists( 'WPBakeryShortCodesContainer' )) {
		class WPBakeryShortCode_accordions extends WPBakeryShortCodesContainer {};
	}
	
	if (class_exists( 'WPBakeryShortCode' )) {
		class WPBakeryShortCode_accordion extends WPBakeryShortCode {};
	}
    
});
