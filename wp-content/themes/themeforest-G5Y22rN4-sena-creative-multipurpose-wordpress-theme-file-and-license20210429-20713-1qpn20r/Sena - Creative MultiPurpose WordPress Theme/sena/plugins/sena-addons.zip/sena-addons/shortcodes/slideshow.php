<?php
// Slideshow ([slideshow])
class Sena_Shortcode_Slideshow {
    
    static $arrImages = array( );
    static $slideId = 0;
    
    public static function slideshow( $atts, $content = null ) {
		extract( shortcode_atts( array(
            'images'            => '',
			'slideshow_timeout' => '10'
		), $atts ) );
        
        $ids = explode(',', $images);
        foreach ( $ids as $id ) {
            self::$arrImages[ ] = wp_get_attachment_url( $id );
        }
        
        return '<div class="intro-slideshow owl-carousel owl-theme full-width" data-delay="' . esc_attr( intval( $slideshow_timeout ) ) . '">' . do_shortcode( $content ) . '</div>';
	}
	
	public static function vc_slideshow() {
		vc_map( array(
		   	"name" => esc_html__( "Slideshow", "sena-addons" ),
		   	"base" => "slideshow",
		   	"icon" => 'ti-layout-slider',
            "description" => esc_html__( "Intro slide background", "sena-addons" ),
			"as_parent" => array(
            	"only" => "slide"
   			),
			"js_view" => "VcColumnView",
			"category" => esc_html__( "Sena", "sena-addons" ),
			"params" => array(
                array(
					"type"        => "attach_images",
					"heading"     => esc_html__( "Images", "sena-addons" ),
					"param_name"  => "images",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Slideshow Timeout", "sena-addons" ),
					"param_name"  => "slideshow_timeout",
					"value"       => "10",
					"description" => "Enter value in seconds",
					"admin_label" => true,
			  	),
			)
		));
	}

	// Slide ([slide])
	public static function slide( $atts, $content = null ) {
		extract( shortcode_atts( array( ), $atts ) );
        
        $img = isset( self::$arrImages[ self::$slideId ] ) ? self::$arrImages[ self::$slideId ] : '';
        self::$slideId ++;
		
		return '<!-- Slide -->
                <div class="item bg-img text-center" data-bg="' . $img . '">
                    <div class="caption">
                        ' . do_shortcode( $content ) . '
                    </div>
                </div>';	
	}
	
	public static function vc_slide() {
		vc_map( array(
		   	"name" => esc_html__( "Slide", "sena-addons" ),
		   	"base" => "slide",
		   	"icon" => 'ti-layout-slider',
			"as_child" => array(
            	"only" => "slideshow"
   			),
		   	"category" => esc_html__( "Sena", "sena-addons" ),
		   	"params" => array(
				array(
					"type"        => "textarea_html",
					"heading"     => esc_html__( "Content", "sena-addons" ),
					"param_name"  => "content",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),                
			)
		));
	}
    
}

add_shortcode( 'slideshow', 	array( 'Sena_Shortcode_Slideshow', 'slideshow' ) );
add_shortcode( 'slide', 		array( 'Sena_Shortcode_Slideshow', 'slide' ) );
add_action( 'vc_before_init', 	array( 'Sena_Shortcode_Slideshow', 'vc_slideshow' ) );
add_action( 'vc_before_init', 	array( 'Sena_Shortcode_Slideshow', 'vc_slide' ) );

// Nested shortcodes
add_action( 'vc_before_init', function() {
    
    // Features extend
	if (class_exists( 'WPBakeryShortCodesContainer' )) {
		class WPBakeryShortCode_slideshow extends WPBakeryShortCodesContainer {};
	}
	
	if (class_exists( 'WPBakeryShortCode' )) {
		class WPBakeryShortCode_slide extends WPBakeryShortCode {};
	}
    
});

