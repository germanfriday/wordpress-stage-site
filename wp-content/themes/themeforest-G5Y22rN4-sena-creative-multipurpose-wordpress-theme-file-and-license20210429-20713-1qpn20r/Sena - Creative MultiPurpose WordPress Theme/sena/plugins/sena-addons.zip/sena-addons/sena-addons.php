<?php
/*
Plugin Name: Sena Addons
Description: Core features for the Sena theme.
Version: 1.4
Author: AthenaStudio
Author URI: https://themeforest.net/user/athenastudio
License: GNU General Public License version 3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Text Domain: sena-addons
*/

if ( ! function_exists( 'add_action' ) ) {
	echo esc_html( "Hi there! I'm just a plugin, not much I can do when called directly." );
	exit;
}

define( 'SENA_PLUGIN_DIR',      plugin_dir_path( __FILE__ ) );

// Localization
function senaPluginLocalization( ) {
	load_plugin_textdomain( 'sena-addons', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}

add_action( 'plugins_loaded', 'senaPluginLocalization' );

// Include features
require_once SENA_PLUGIN_DIR . 'linea/icons.php';
require_once SENA_PLUGIN_DIR . 'shortcodes/class.shortcodes.php';
require_once SENA_PLUGIN_DIR . 'widgets/class.widgets.php';
require_once SENA_PLUGIN_DIR . 'posts/class.posts.php';
require_once SENA_PLUGIN_DIR . 'post-like/post-like.php';
require_once SENA_PLUGIN_DIR . 'options/class.options.php';

