<?php
class Sena_Shortcodes {
	
    // Convert columns
	public static function getColumnsNumber( $fraction ) {
		list( $x, $y ) = explode( '/', $fraction );

		$x = intval( $x ) > 0 ? intval( $x ) : 1;
		$y = intval( $y ) > 0 ? intval( $y ) : 1;

		return round( $x * ( 12 / $y ) );
	}
	
	// Share
	public static function share( $text = true, $title = null, $image = null, $url = null ) {
		global $sena_config;
		
		if ( $title ) {
			$output =  '<div class="share-panel share-btn">
							<p><i class="fas fa-share-alt"></i>' . esc_html__( 'Share', 'sena-addons' ) .'</p>
					   		<ul>
								<li><a title="' . esc_html__( "Twitter", "sena-addons" ) . '" onclick="shareTo( \'twitter\', \'' . esc_js( $title ) . '\', \'' . esc_js( $image ) . '\', \'' . esc_js( $url ) . '\' )"><i class="fab fa-twitter"></i></a></li>
								<li><a title="' . esc_html__( "Facebook", "sena-addons" ) . '" onclick="shareTo( \'facebook\', \'' . esc_js( $title ) . '\', \'' . esc_js( $image ) . '\', \'' . esc_js( $url ) . '\' )"><i class="fab fa-facebook-f"></i></a></li>
								<li><a title="' . esc_html__( "Pinterest", "sena-addons" ) . '" onclick="shareTo( \'pinterest\', \'' . esc_js( $title ) . '\', \'' . esc_js( $image ) . '\', \'' . esc_js( $url ) . '\' )"><i class="fab fa-pinterest"></i></a></li>
								<li><a title="' . esc_html__( "LinkedIn", "sena-addons" ) . '" onclick="shareTo( \'linkedin\', \'' . esc_js( $title ) . '\', \'' . esc_js( $image ) . '\', \'' . esc_js( $url ) . '\' )"><i class="fab fa-linkedin-in"></i></a></li>
							</ul>
						</div>';
		} else {
			if ( $title == null ) $title = "#share-title";
			
			$output = '<div class="share-panel">
							<div class="social">
								<a title="' . esc_html__( "Twitter", "sena-addons" ) . '" onclick="shareTo( \'twitter\', \'' . esc_js( $title ) . '\', \'' . esc_js( $image ) . '\', \'' . esc_js( $url ) . '\' )"><i class="fab fa-twitter"></i></a>
								<a title="' . esc_html__( "Facebook", "sena-addons" ) . '" onclick="shareTo( \'facebook\', \'' . esc_js( $title ) . '\', \'' . esc_js( $image ) . '\', \'' . esc_js( $url ) . '\' )"><i class="fab fa-facebook-f"></i></a>
								<a title="' . esc_html__( "Pinterest", "sena-addons" ) . '" onclick="shareTo( \'pinterest\', \'' . esc_js( $title ) . '\', \'' . esc_js( $image ) . '\', \'' . esc_js( $url ) . '\' )"><i class="fab fa-pinterest"></i></a>
								<a title="' . esc_html__( "LinkedIn", "sena-addons" ) . '" onclick="shareTo( \'linkedin\', \'' . esc_js( $title ) . '\', \'' . esc_js( $image ) . '\', \'' . esc_js( $url ) . '\' )"><i class="fab fa-linkedin-in"></i></a>
							</div>
					   </div>';
		}
		
		return $output;
	}
	
}

// Include shortcodes
require_once SENA_PLUGIN_DIR . 'shortcodes/slideshow.php';
require_once SENA_PLUGIN_DIR . 'shortcodes/single-image.php';
require_once SENA_PLUGIN_DIR . 'shortcodes/video-background.php';
require_once SENA_PLUGIN_DIR . 'shortcodes/section-title.php';
require_once SENA_PLUGIN_DIR . 'shortcodes/button.php';
require_once SENA_PLUGIN_DIR . 'shortcodes/skills.php';
require_once SENA_PLUGIN_DIR . 'shortcodes/services.php';
require_once SENA_PLUGIN_DIR . 'shortcodes/team-members.php';
require_once SENA_PLUGIN_DIR . 'shortcodes/portfolio.php';
require_once SENA_PLUGIN_DIR . 'shortcodes/info-box.php';
require_once SENA_PLUGIN_DIR . 'shortcodes/counters.php';
require_once SENA_PLUGIN_DIR . 'shortcodes/testimonials.php';
require_once SENA_PLUGIN_DIR . 'shortcodes/video.php';
require_once SENA_PLUGIN_DIR . 'shortcodes/accordions.php';
require_once SENA_PLUGIN_DIR . 'shortcodes/pricing-tables.php';
require_once SENA_PLUGIN_DIR . 'shortcodes/clients.php';
require_once SENA_PLUGIN_DIR . 'shortcodes/google-maps.php';
require_once SENA_PLUGIN_DIR . 'shortcodes/contact-form.php';
require_once SENA_PLUGIN_DIR . 'shortcodes/contact-info.php';
require_once SENA_PLUGIN_DIR . 'shortcodes/slider.php';
require_once SENA_PLUGIN_DIR . 'shortcodes/blog.php';

