<?php
// Section title ([section_title])
class Sena_Shortcode_Section_Title {
    
    public static function sectionTitle( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'title'  	=> '',
			'subtitle'  => '',
			'color'  	=> '',
			'align'  	=> 'text-center',
			'fullwidth' => 'true'
		), $atts ) );
		
		$output = '';
		
		if ( $fullwidth == 'true' ) {
			$output .= '<div class="row"><div class="col-md-8 col-md-offset-2 col-xs-12">';
		}
		
		$output .= '<div class="section-title ' . $color . ' ' . $align . '"><h3>' . esc_html( $subtitle ) . '</h3><h2>' . wp_kses( $title, 'strong' ) . '</h2>' . (strlen( $content ) > 0 ? '<p>' . do_shortcode( $content ) . '</p>' : '') . '</div>';
		
		if ( $fullwidth == 'true' ) {
			$output .= '</div></div>';
		}
		
		return $output;
	}
	
	public static function vc_sectionTitle() {
		vc_map( array(
		   	"name" => esc_html__( "Section Title", "sena-addons" ),
		   	"base" => "section_title",
		   	"icon" => 'ti-uppercase',
            "description" => esc_html__( "Styled heading", "sena-addons" ),
		   	"category" => esc_html__( "Sena", "sena-addons" ),
		   	"params" => array(
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Title", "sena-addons" ),
					"param_name"  => "title",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Subtitle", "sena-addons" ),
					"param_name"  => "subtitle",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
				array(
					"type"        => "textarea_html",
					"heading"     => esc_html__( "Slogan", "sena-addons" ),
					"param_name"  => "content",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
				array(
				 	"type" => "dropdown",
				 	"holder" => "div",
					"class" => "",
				 	"heading" => esc_html__("Color", 'sena-addons'),
				 	"param_name" => "color",
				 	"value" => array(   
						esc_html__( "Dark", "sena-addons" ) => '',
						esc_html__( "White", "sena-addons" ) => 'white'
					),
					"description" => "",
					"admin_label" => true,
			  	),
				array(
				 	"type" => "dropdown",
				 	"holder" => "div",
					"class" => "",
				 	"heading" => esc_html__("Align", 'sena-addons'),
				 	"param_name" => "align",
				 	"value" => array(   
						esc_html__( "Center", "sena-addons" ) => 'text-center',
						esc_html__( "Left", "sena-addons" ) => 'text-left'
					),
					"description" => "",
					"admin_label" => true,
			  	),
				array(
					"type"        => "checkbox",
					"heading"     => esc_html__( "Full Width", "sena-addons" ),
					"param_name"  => "fullwidth",
					"value"       => "",
					"std" 		  => "true",
					"description" => "",
					"admin_label" => true,
			  	)
			)
		));
	}
    
}

add_shortcode( 'section_title', array( 'Sena_Shortcode_Section_Title', 'sectionTitle' ) );
add_action( 'vc_before_init', 	array( 'Sena_Shortcode_Section_Title', 'vc_sectionTitle' ) );

