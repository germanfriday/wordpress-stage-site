<?php
// Video Background (Intro) ([video_background])
class Sena_Shortcode_Video_Background {
    
    public static function videoBackground( $atts, $content = null ) {
		extract( shortcode_atts( array(
            'video_url'         => '',
            'video_image'       => '',
            'video_start_at'    => '0',
            'play_button'       => 'true',
            'mute'              => 'true',
            'volume'            => '100',
            'overlay'           => '40',
		), $atts ) );
        
        //Fallback image
        if ( ! empty( $video_image ) ) {
             $video_image = wp_get_attachment_url( $video_image );
        }
        
        //Play button
        $btn = '';
        
        if ($play_button=='true') {
            $btn = '<div id="video-mode" class="video-control"><i class="fas fa-play"></i></div>';
        }
        
        return  '<!-- Youtube player -->
                 <div class="slider fullscreen"
                    data-overlay="' . esc_attr( (int) $overlay / 100 ) . '"
                    data-property="{
                        videoURL:\'' . esc_url( $video_url ) . '\',
                        mobileFallbackImage:\'' . esc_url( $video_image ) . '\',
                        startAt:' . esc_js( intval( $video_start_at ) ) . ', 
                        mute:' . esc_js( $mute ) . ', 
                        vol:' . esc_js( intval( $volume ) ) . ',
                        autoPlay:true, 
                        showControls:false,
                        showYTLogo:false,
                        opacity:1                        
                    }">
                 </div>
                 
                 <div class="row">
                    <div class="col-md-12 text-center">
                        <div class="caption">' . $btn . do_shortcode( $content ) . '</div>
                    </div>
                 </div>';
	}
	
	public static function vc_videoBackground() {
		vc_map( array(
		   	"name" => esc_html__( "Video Background", "sena-addons" ),
		   	"base" => "video_background",
		   	"icon" => 'ti-control-shuffle',
            "description" => esc_html__( "Intro video background", "sena-addons" ),
		   	"category" => esc_html__( "Sena", "sena-addons" ),
		   	"params" => array(
                array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Youtube Video URL", "sena-addons" ),
					"param_name"  => "video_url",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
                array(
					"type"        => "attach_image",
					"heading"     => esc_html__( "Mobile Fallback Image", "sena-addons" ),
					"param_name"  => "video_image",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
                array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Start Video At", "sena-addons" ),
					"param_name"  => "video_start_at",
					"value"       => "0",
					"description" => esc_html__( "Enter value in seconds", "sena-addons" ),
					"admin_label" => true,
			  	),
                array(
					"type"        => "checkbox",
					"heading"     => esc_html__( "Show Play Button", "sena-addons" ),
					"param_name"  => "play_button",
					"value"       => "",
					"std" 		  => "true",
					"description" => "",
					"admin_label" => true,
			  	),
                array(
					"type"        => "checkbox",
					"heading"     => esc_html__( "Video Mutted", "sena-addons" ),
					"param_name"  => "mute",
					"value"       => "",
					"std" 		  => "true",
					"description" => "",
					"admin_label" => true,
			  	),
                array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Video Volume", "sena-addons" ),
					"param_name"  => "volume",
					"value"       => "100",
					"description" => esc_html__( "Enter value between 0 and 100", "sena-addons" ),
					"admin_label" => true,
			  	),
                array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Video Overlay Opacity", "sena-addons" ),
					"param_name"  => "overlay",
					"value"       => "40",
					"description" => esc_html__( "In percents (0% &ndash; fully transparent)", "sena-addons" ),
					"admin_label" => true,
			  	),
                array(
					"type"        => "textarea_html",
					"heading"     => esc_html__( "Content", "sena-addons" ),
					"param_name"  => "content",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
			)
		));
	}
    
}

add_shortcode( 'video_background', 	array( 'Sena_Shortcode_Video_Background', 'videoBackground' ) );
add_action( 'vc_before_init', 	array( 'Sena_Shortcode_Video_Background', 'vc_videoBackground' ) );

