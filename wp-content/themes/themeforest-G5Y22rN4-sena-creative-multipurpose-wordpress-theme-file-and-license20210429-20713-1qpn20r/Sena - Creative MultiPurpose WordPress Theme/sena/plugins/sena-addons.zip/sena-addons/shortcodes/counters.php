<?php
// Milestone counters ([milestone])
class Sena_Shortcode_Milestone_Counters {
    
    static $milestoneCounters;
    
    public static function milestone( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'mt' => '0px',
			'mb' => '0px',
		), $atts ) );
		
		$mt = intval( $mt );
		$mb = intval( $mb );

		$style = ( $mt > 0 || $mb > 0 ) ? 'style="margin-top: ' . $mt . 'px; margin-bottom: ' . $mb . 'px;"' : '';	
		
		return '<div class="row counters" ' . $style . '>' . do_shortcode( $content ) . '</div>';
	}
	
	public static function vc_milestone() {
		vc_map( array(
		   	"name" => esc_html__( "Counters", "sena-addons" ),
		   	"base" => "milestone",
		   	"icon" => 'ti-dashboard',
            "description" => esc_html__( "Milestone numbers", "sena-addons" ),
			"as_parent" => array(
            	"only" => "counter"
   			),
			"show_settings_on_create" => false,
			"js_view" => "VcColumnView",
			"category" => esc_html__( "Sena", "sena-addons" ),
			"params" => array(
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Margin Top", "sena-addons" ),
					"param_name"  => "mt",
					"value"       => "0px",
					"description" => "",
					"admin_label" => true,
			  	),
			  	array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Margin Bottom", "sena-addons" ),
					"param_name"  => "mb",
					"value"       => "0px",
					"description" => "",
					"admin_label" => true,
			  	),
			)
		));
	}
	
	// Milestone counter ([counter])
	public static function counter( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'title'  => '',
			'icon'   => '',
			'count'   => '',
			'column' => '1/4'
		), $atts ) );
		
		self::$milestoneCounters = ( self::$milestoneCounters > 0 ) ? ( int ) self::$milestoneCounters : 0;
		self::$milestoneCounters ++;

		return '<div class="col-md-' . Sena_Shortcodes::getColumnsNumber( $column ) . '"><div class="counter wow fadeInUp" data-wow-delay="' . ( 0.3 * ( self::$milestoneCounters - 1 ) ) . 's"><div class="icon ' . esc_attr( $icon ) . '"></div><div class="counter-content res-margin"><h5><span class="number-count">' . intval( $count ) . '</span></h5><p>' . esc_html( $title ) . '</p></div></div></div>';
	}
	
	public static function vc_counter() {
		vc_map( array(
		   	"name" => esc_html__( "Counter", "sena-addons" ),
		   	"base" => "counter",
		   	"icon" => 'ti-star',
			"as_child" => array(
            	"only" => "milestone"
   			),
		   	"category" => esc_html__( "Sena", "sena-addons" ),
		   	"params" => array(
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Title", "sena-addons" ),
					"param_name"  => "title",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
				array(
					"type" => "iconpicker",
					"heading" => esc_html__( "Icon", "sena-addons" ),
					"param_name" => "icon",
					"value" => "",
					"settings" => array(
					  	"emptyIcon" => true,
                        'type' => 'linea',
					  	"iconsPerPage" => 4000,
					),
					"dependency" => array(
					  	"element" => "type",
					  	"value" => "linea",
					),
				),
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Count", "sena-addons" ),
					"param_name"  => "count",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
				array(
				 	"type" => "dropdown",
				 	"holder" => "div",
				 	"class" => "",
				 	"heading" => esc_html__( "Column", "sena-addons" ),
				 	"param_name" => "column",
				 	"value" => array(   
						"1/2" => '1/2',
						"1/3" => '1/3',
						"1/4" => '1/4',
						"1/6" => '1/6'
					),
					"std" => "1/4",
				 	"description" => "",
					"admin_label" => true,
			  	),
			  	array(
					"type"        => "textfield",
					"heading"     => esc_html__( "CSS Class", "sena-addons" ),
					"param_name"  => "class",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
			)
		));
	}
    
}

add_shortcode( 'milestone', 	array( 'Sena_Shortcode_Milestone_Counters', 'milestone' ) );
add_shortcode( 'counter', 		array( 'Sena_Shortcode_Milestone_Counters', 'counter' ) );
add_action( 'vc_before_init', 	array( 'Sena_Shortcode_Milestone_Counters', 'vc_milestone' ) );
add_action( 'vc_before_init', 	array( 'Sena_Shortcode_Milestone_Counters', 'vc_counter' ) );

// Nested shortcodes
add_action( 'vc_before_init', function() {
    
    //Milestone counters extend
	if (class_exists( 'WPBakeryShortCodesContainer' )) {
		class WPBakeryShortCode_milestone extends WPBakeryShortCodesContainer {};
	}
	
	if (class_exists( 'WPBakeryShortCode' )) {
		class WPBakeryShortCode_counter extends WPBakeryShortCode {};
	}
    
});

