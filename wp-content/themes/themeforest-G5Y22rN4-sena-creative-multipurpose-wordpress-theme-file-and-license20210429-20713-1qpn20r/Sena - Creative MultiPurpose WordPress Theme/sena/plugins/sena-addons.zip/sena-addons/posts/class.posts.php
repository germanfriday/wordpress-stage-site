<?php
class Sena_Posts {
	
	// Initialization
	public static function sena_initialize( ) {
		// Register portfolio taxonomy
		$args = array(
			'hierarchical'       => true,
			'labels'             => array(
				'name'                => esc_html__( 'Category', 'sena' ),
				'singular_name'       => esc_html__( 'Category', 'sena' ),
				'search_items'        => esc_html__( 'Search Categories', 'sena' ),
				'all_items'           => esc_html__( 'All Categories', 'sena' ),
				'parent_item'         => esc_html__( 'Parent Category', 'sena' ),
				'parent_item_colon'   => esc_html__( 'Parent Category:', 'sena' ),
				'edit_item'           => esc_html__( 'Edit Category', 'sena' ), 
				'update_item'         => esc_html__( 'Update Category', 'sena' ),
				'add_new_item'        => esc_html__( 'Add New Category', 'sena' ),
				'new_item_name'       => esc_html__( 'New Category', 'sena' ),
				'menu_name'           => esc_html__( 'Categories', 'sena' ),
			),
			'show_ui'            => true,
			'show_admin_column'  => true,
			'query_var'          => true,
			'rewrite'            => array( 'slug' => 'portfolio-category' )
		);
		register_taxonomy( 'portfolio-category', 'portfolio', $args );

		// Register portfolio
		$args = array(
			'labels'             => array(
				'name'                 => esc_html__( 'Portfolio', 'sena' ),
				'singular_name'        => esc_html__( 'Portfolio', 'sena' ),
				'add_new'              => esc_html__( 'Add New', 'sena' ),
				'add_new_item'         => esc_html__( 'Add New Item', 'sena' ),
				'edit_item'            => esc_html__( 'Edit Item', 'sena' ),
				'new_item'             => esc_html__( 'New Item', 'sena' ),
				'all_items'            => esc_html__( 'All Items', 'sena' ),
				'view_item'            => esc_html__( 'View Items', 'sena' ),
				'search_items'         => esc_html__( 'Search Items', 'sena' ),
				'not_found'            => esc_html__( 'No Item found', 'sena' ),
				'not_found_in_trash'   => esc_html__( 'No Item found in Trash', 'sena' ),
				'menu_name'            => esc_html__( 'Portfolio', 'sena' ),
				'parent_item_colon'    => '',
			),
			'exclude_from_search' => true,
			'public'              => true,
			'publicly_queryable'  => true,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'query_var'           => true,
			'rewrite'             => array( 'slug' => esc_html__( 'portfolio', 'sena' ) ),
			'capability_type'     => 'page',
			'has_archive'         => true,
			'hierarchical'        => false,
			'menu_position'       => null,
			'menu_icon'           => 'dashicons-portfolio',
			'supports'            => array( 'title', 'editor', 'thumbnail', 'page-attributes', 'portfolio-category' ),
			'taxonomies'          => array( 'portfolio-category' ),
		);
		register_post_type( 'portfolio', $args );
	}
	
}

add_action( 'init', array( 'Sena_Posts', 'sena_initialize' ) );