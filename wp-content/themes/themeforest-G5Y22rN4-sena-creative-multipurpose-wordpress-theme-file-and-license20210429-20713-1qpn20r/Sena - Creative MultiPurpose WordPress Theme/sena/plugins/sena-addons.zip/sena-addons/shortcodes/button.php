<?php
// Button ([button])
class Sena_Shortcode_Button {
    
    public static function button( $atts, $content = null ) {
		extract( shortcode_atts( array(
			'button_type'   => 'btn-default',
			'url'     		=> '',
			'target'  		=> '',
			'icon'    		=> ''			
		), $atts ) );
		
		$url = vc_build_link( $url );
		$target = strlen( $url['target'] ) > 0 ? $url['target'] : $target;
		$url = strlen( $url['url'] ) > 0 ? $url['url'] : '';

		return '<a href="' . esc_url( $url ) . '" ' . ( ( $target != '' && $target != '_self' ) ? ' target="' . esc_attr( $target ) . '"' : '' ) . ' class="btn ' . esc_attr( $button_type ) . '">' . ( ! empty( $icon ) ? ' <i class="' . esc_attr( $icon ) . '"></i>' : '' ) . $content . '</a>';
	}
	
	public static function vc_button() {
		vc_map( array(
		   	"name" => esc_html__( "Button", "sena-addons" ),
		   	"base" => "button",
		   	"icon" => 'ti-arrow-circle-right',
            "description" => esc_html__( "Custom button", "sena-addons" ),
		   	"category" => esc_html__( "Sena", "sena-addons" ),
		   	"params" => array(
				array(
				 	"type" => "dropdown",
				 	"holder" => "div",
					"class" => "",
				 	"heading" => esc_html__("Type", 'sena-addons'),
				 	"param_name" => "button_type",
				 	"value" => array(   
						esc_html__( "Default", "sena-addons" ) 	=> 'btn-default',
						esc_html__( "Rounded", "sena-addons" ) 	=> 'btn-default btn-rounded',
						esc_html__( "Bordered", "sena-addons" ) 	=> 'btn-rounded btn-white btn-inverse'
					),
					"description" => "",
					"admin_label" => true,
			  	),
				array(
					"type"        => "textfield",
					"heading"     => esc_html__( "Text", "sena-addons" ),
					"param_name"  => "content",
					"value"       => "",
					"description" => "",
					"admin_label" => true,
			  	),
			  	array(
					'type' 		  => 'vc_link',
					'heading' 	  => esc_html__( 'URL', 'sena-addons' ),
					'param_name'  => 'url',
					'description' => "",
					"admin_label" => true,
			  	),
				array(
					"type" 		  => "dropdown",
					"heading" 	  => esc_html__( "Icon library", "sena-addons" ),
					"value" 	  => array(
					  esc_html__( "Font Awesome", "sena-addons" ) => "fontawesome",
					),
					"admin_label" => false,
					"param_name"  => "type",
					"description" => "",
				),
				array(
					"type" => "iconpicker",
					"heading" => esc_html__( "Icon", "sena-addons" ),
					"param_name" => "icon",
					"value" => "",
					"settings" => array(
					  "emptyIcon" => true,
					  "iconsPerPage" => 4000,
					),
					"dependency" => array(
					  "element" => "type",
					  "value" => "fontawesome",
					),
				),
			)
		));
	}	
    
}

add_shortcode( 'button', 		array( 'Sena_Shortcode_Button', 'button' ) );
add_action( 'vc_before_init', 	array( 'Sena_Shortcode_Button', 'vc_button' ) );

