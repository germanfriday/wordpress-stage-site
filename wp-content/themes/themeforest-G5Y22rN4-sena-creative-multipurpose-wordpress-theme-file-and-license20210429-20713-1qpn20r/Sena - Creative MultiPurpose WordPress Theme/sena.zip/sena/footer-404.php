<?php global $sena_config; ?>
		
		<?php Sena_Theme::sena_inline_scripts( get_the_ID( ) ); ?>
		
		<?php wp_footer( ); ?>
		
	</body>
</html>