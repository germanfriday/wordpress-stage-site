<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => __( 'Contact form', 'vispa' ),
	'description' => __( 'Build contact forms', 'vispa' ),
	'tab'         => __( 'Content Elements', 'vispa' ),
	'popup_size'  => 'large',
	'type'        => 'special'
);