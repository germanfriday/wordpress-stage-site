<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => __( 'Tabs', 'vispa' ),
	'description' => __( 'Add some Tabs', 'vispa' ),
	'tab'         => __( 'Content Elements', 'vispa' ),
);