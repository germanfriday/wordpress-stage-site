<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array(
	'page_builder' => array(
		'title'       => __( 'Gallery', 'vispa' ),
		'description' => __( 'Add a gallery', 'vispa' ),
		'tab'         => __( 'Content Elements', 'vispa' ),
		'popup_size'  => 'medium',
	)
);
