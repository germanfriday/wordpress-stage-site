<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => __( 'Slider', 'vispa' ),
	'description' => __( 'Add a Slider', 'vispa' ),
	'tab'         => __( 'Media Elements', 'vispa' ),
	'popup_size'  => 'small',
);
