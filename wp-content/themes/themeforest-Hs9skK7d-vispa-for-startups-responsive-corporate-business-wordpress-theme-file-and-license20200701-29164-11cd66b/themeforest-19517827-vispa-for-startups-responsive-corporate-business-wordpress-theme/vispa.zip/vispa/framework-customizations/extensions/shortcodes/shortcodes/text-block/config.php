<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array(
	'page_builder' => array(
		'title'       => esc_html__( 'Text Block', 'vispa' ),
		'description' => esc_html__( 'A very awesome text block', 'vispa' ),
		'tab'         => esc_html__( 'Content Elements', 'vispa' ),
	)
);
