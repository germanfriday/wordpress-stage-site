<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array(
	'page_builder' => array(
		'title'       => __( 'Portfolio', 'vispa' ),
		'description' => __( 'Portfolio Shortcode', 'vispa' ),
		'tab'         => __( 'Content Elements', 'vispa' ),
		'popup_size'  => 'medium'
	)
);