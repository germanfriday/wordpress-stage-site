<?php
get_template_part( 'framework-customizations/extensions' . fw()->extensions->get( 'portfolio' )->get_rel_path() . '/views/archive' );