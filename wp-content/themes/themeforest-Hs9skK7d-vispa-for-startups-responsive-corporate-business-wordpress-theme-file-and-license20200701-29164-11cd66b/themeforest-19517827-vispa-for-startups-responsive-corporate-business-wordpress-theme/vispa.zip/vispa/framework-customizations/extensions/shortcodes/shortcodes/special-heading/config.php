<?php if (!defined('FW')) die('Forbidden');

$cfg = array();

$cfg['page_builder'] = array(
	'title'         => __('Special Heading', 'vispa'),
	'description'   => __('Add a Special Heading', 'vispa'),
	'tab'           => __('Content Elements', 'vispa'),
);