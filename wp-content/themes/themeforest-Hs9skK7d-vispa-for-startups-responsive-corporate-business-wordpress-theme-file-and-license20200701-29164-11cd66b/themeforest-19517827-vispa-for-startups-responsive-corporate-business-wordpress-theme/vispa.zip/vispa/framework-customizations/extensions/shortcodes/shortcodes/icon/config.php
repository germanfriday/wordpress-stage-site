<?php if (!defined('FW')) die('Forbidden');

$cfg = array();

$cfg['page_builder'] = array(
	'title'         => __('Icon', 'vispa'),
	'description'   => __('Add an Icon', 'vispa'),
	'tab'           => __('Content Elements', 'vispa'),
);