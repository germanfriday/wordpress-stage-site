<?php if (!defined('FW')) die('Forbidden');

$cfg = array();

$cfg['page_builder'] = array(
	'title'         => __('Image', 'vispa'),
	'description'   => __('Add an Image', 'vispa'),
	'tab'           => __('Media Elements', 'vispa'),
);