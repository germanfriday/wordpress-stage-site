<?php if (!defined('FW')) die('Forbidden');

$cfg = array();

$cfg['page_builder'] = array(
	'title'         => __('Icon Box', 'vispa'),
	'description'   => __('Add an Icon Box', 'vispa'),
	'tab'           => __('Content Elements', 'vispa')
);