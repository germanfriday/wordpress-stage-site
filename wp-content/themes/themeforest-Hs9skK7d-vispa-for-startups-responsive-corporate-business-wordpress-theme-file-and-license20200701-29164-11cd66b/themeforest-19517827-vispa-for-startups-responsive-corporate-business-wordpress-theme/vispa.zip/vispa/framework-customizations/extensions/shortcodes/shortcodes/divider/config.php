<?php if (!defined('FW')) die('Forbidden');

$cfg = array();

$cfg['page_builder'] = array(
	'title'         => __('Divider', 'vispa'),
	'description'   => __('Add a Divider', 'vispa'),
	'tab'           => __('Content Elements', 'vispa'),
	'popup_size'    => 'small'
);