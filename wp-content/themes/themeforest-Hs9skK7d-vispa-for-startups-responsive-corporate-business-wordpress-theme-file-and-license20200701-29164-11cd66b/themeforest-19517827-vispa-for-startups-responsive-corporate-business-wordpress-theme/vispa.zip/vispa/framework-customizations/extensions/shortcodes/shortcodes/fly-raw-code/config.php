<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array(
	'page_builder' => array(
		'title'       => __( 'RAW Code', 'vispa' ),
		'description' => __( 'Add a raw code', 'vispa' ),
		'tab'         => __( 'Content Elements', 'vispa' ),
		'popup_size'  => 'medium',
	)
);
