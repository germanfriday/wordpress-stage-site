<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => __( 'Map', 'vispa' ),
	'description' => __( 'Add a Map', 'vispa' ),
	'tab'         => __( 'Content Elements', 'vispa' ),
);