<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array(
	'page_builder' => array(
		'title'       => esc_html__( 'Performance', 'vispa' ),
		'description' => esc_html__( 'Performance shortcode', 'vispa' ),
		'tab'         => esc_html__( 'Content Elements', 'vispa' ),
		'popup_size'  => 'medium'
	)
);