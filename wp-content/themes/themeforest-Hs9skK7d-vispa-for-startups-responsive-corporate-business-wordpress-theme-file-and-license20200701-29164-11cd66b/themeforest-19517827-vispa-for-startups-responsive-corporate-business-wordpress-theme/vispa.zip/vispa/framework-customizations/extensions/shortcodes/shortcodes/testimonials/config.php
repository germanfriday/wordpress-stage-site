<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => __( 'Testimonials', 'vispa' ),
	'description' => __( 'Add some Testimonials', 'vispa' ),
	'tab'         => __( 'Content Elements', 'vispa' ),
);