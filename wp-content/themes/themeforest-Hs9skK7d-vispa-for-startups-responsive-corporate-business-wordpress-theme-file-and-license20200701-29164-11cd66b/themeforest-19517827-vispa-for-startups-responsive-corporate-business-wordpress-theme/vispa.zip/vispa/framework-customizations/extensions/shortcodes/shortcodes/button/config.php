<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array(
	'page_builder' => array(
		'title'       => esc_html__( 'Button', 'vispa' ),
		'description' => esc_html__( 'Add a Button', 'vispa' ),
		'tab'         => esc_html__( 'Content Elements', 'vispa' ),
		'popup_size'  => 'small'
	)
);