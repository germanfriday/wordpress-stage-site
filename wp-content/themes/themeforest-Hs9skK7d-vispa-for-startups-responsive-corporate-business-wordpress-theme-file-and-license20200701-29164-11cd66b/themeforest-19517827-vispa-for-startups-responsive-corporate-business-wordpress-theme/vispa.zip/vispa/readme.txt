Author: https://flytemplates.com/
Docs: http://docs.flytemplates.com/vispa/

Vispa - is a business blog WordPress Theme.

---------------
Very Important!
---------------

After you've uploaded the theme on your server it is important to use (activate) the child theme. 
This will enable you to make any modifications to the theme and not lose them when you'll 
get a future update to the main theme. 