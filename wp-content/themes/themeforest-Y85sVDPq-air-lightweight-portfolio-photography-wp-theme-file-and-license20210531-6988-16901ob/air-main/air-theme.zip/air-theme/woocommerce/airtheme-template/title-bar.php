<div class="archive-title title-wrap">
    <div class="title-wrap-con">
          <h2 class="title-wrap-tit"><?php woocommerce_page_title(); ?></h2>
          <div class="archive-des"><?php echo esc_html($wp_query->found_posts); esc_html_e(' items found','air-theme'); ?></div>
    </div>
</div>