<?php $search_text = esc_html__('Enter a Key Word Here','air-theme'); ?>
<div id="search-overlay">
    <form method="get" class="container-inn search-overlay-form middle-ux">
        <input type="text" name="s" class="search-overlay-input-text" placeholder="<?php echo esc_attr($search_text); ?>">
    </form>
    <div id="search-overlay-close"><div class="menu-panel-close"></div></div>
</div>