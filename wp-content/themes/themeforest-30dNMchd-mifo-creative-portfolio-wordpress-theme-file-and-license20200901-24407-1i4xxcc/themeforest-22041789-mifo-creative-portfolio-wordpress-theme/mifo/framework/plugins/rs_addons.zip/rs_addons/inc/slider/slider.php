<?php
/**
 * Team custom post type
 * This file is the basic custom post type for use any where in theme.
 * 
 * @package rs
 * @author RS Theme
 * @link http://www.rstheme.com
 */
// Register Slider Post Type
function rs_sider_register_post_type() {
	$labels = array(
		'name'               => esc_html__( 'Sliders', 'rs-option' ),
		'singular_name'      => esc_html__( 'Slider', 'rs-option' ),
		'add_new'            => esc_html_x( 'Add New Slide', 'rs-option', 'rs-option' ),
		'add_new_item'       => esc_html__( 'Add New Slide', 'rs-option' ),
		'edit_item'          => esc_html__( 'Edit Slide', 'rs-option' ),
		'new_item'           => esc_html__( 'New Slider', 'rs-option' ),
		'all_items'          => esc_html__( 'All Slides', 'rs-option' ),
		'view_item'          => esc_html__( 'View Slider', 'rs-option' ),
		'search_items'       => esc_html__( 'Search Sliders', 'rs-option' ),
		'not_found'          => esc_html__( 'No Sliders found', 'rs-option' ),
		'not_found_in_trash' => esc_html__( 'No Sliders found in Trash', 'rs-option' ),
		'parent_item_colon'  => esc_html__( 'Parent Slider:', 'rs-option' ),
		'menu_name'          => esc_html__( 'Slider', 'rs-option' ),
	);
	$args = array(
		'labels'             => $labels,
		'public'             => true,
		'publicly_queryable' => true,
		'show_in_menu'       => true,
		'show_in_admin_bar'  => true,
		'can_export'         => true,
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => 20,
		'menu_icon'          =>  plugins_url( 'img/icon.png', __FILE__ ),
		'supports'           => array( 'title', 'thumbnail','editor' )
	);
	register_post_type( 'sliders', $args );
}
add_action( 'init', 'rs_sider_register_post_type' );
// Meta Box
/*--------------------------------------------------------------
*			Slider info
*-------------------------------------------------------------*/
function rs_slider_info_meta_box() {
	add_meta_box( 'slider_info_meta', esc_html__( 'Slider Info', 'rs-option' ), 'rs_slider_info_meta_callback', 'sliders', 'advanced', 'high', 1 );
}
add_action( 'add_meta_boxes', 'rs_slider_info_meta_box');
// member info callback
function rs_slider_info_meta_callback( $member_info ) {

	wp_nonce_field( 'rs_slider_metabox', 'rs_slider_metabox_nonce' ); ?>

	<div style="margin: 10px 0;">
		<label for="btn1_text" style="width:150px; display:inline-block;"><?php esc_html_e( 'Button 1 Text', 'rs-option' ) ?></label>
		<?php $btn1_text = get_post_meta( $member_info->ID, 'btn1_text', true ); ?>
		<input type="text" name="btn1_text" id="btn1_text" class="btn1_text" placeholder="Read More" value="<?php echo esc_html($btn1_text); ?>" style="width:300px;"/>
	</div>

	<div style="margin: 10px 0;">
		<label for="btn1_url" style="width:150px; display:inline-block;"><?php esc_html_e( 'Button 1 URL', 'rs-option' ) ?></label>
		<?php $btn1_url = get_post_meta( $member_info->ID, 'btn1_url', true ); ?>
		<input type="text" name="btn1_url" id="btn1_url" class="btn1_url" placeholder="#" value="<?php echo esc_html($btn1_url); ?>" style="width:300px;"/>
	</div>

	<div style="margin: 10px 0;">
		<label for="btn2_text" style="width:150px; display:inline-block;"><?php esc_html_e( 'Button 2 Text', 'rs-option' ) ?></label>
		<?php $btn2_text = get_post_meta( $member_info->ID, 'btn2_text', true ); ?>
		<input type="text" name="btn2_text" id="btn2_text" placeholder="Download Now" class="btn2_text" value="<?php echo esc_html($btn2_text); ?>" style="width:300px;"/>
	</div>

	<div style="margin: 10px 0;">
		<label for="btn2_url" style="width:150px; display:inline-block;"><?php esc_html_e( 'Button 2 URL', 'rs-option' ) ?></label>
		<?php $btn2_url = get_post_meta( $member_info->ID, 'btn2_url', true ); ?>
		<input type="text" name="btn2_url" id="btn2_url" placeholder="#" class="btn2_url" value="<?php echo esc_html($btn2_url); ?>" style="width:300px;"/>
	</div>
	
	<div style="margin: 10px 0;">

		<label for="slide_align" style="width:150px; display:inline-block;"><?php esc_html_e( 'Slide Content Align', 'rs-option' ) ?></label>

	   	<?php $slide_align = get_post_meta( $member_info->ID, 'slide_align', true );; 
			$slidealign  = 'left';
			if ($slide_align !='') {     
				$slidealign = $slide_align;
			}
		?>

		<select name="slide_align" style="width:300px; display:inline-block;">
			<option selected="selected" value = "<?php echo esc_attr( $slidealign);?>"><?php echo esc_attr($slidealign);?></option>
			<option value="left"><?php  esc_html_e('Left','rs-option');?></option>
			<option value="right"><?php  esc_html_e('Right','rs-option');?></option>
			<option value="center"><?php  esc_html_e('Center','rs-option');?></option>
		</select>
	</div>

	<div style="margin: 10px 0;">
		<label for="extra_class" style="width:150px; display:inline-block;"><?php esc_html_e( 'Extra Class', 'rs-option' ) ?></label>
		<?php $extra_class = get_post_meta( $member_info->ID, 'extra_class', true ); ?>
		<input type="text" name="extra_class" id="extra_class" class="extra_class" value="<?php echo esc_html($extra_class); ?>" style="width:300px;"/>
	</div>

<?php }

/*------------------------------------------------------------
 *			Save member social meta
*-------------------------------------------------------------*/
function save_rs_slider_meta( $post_id ) {
	if ( ! isset( $_POST['rs_slider_metabox_nonce'] ) ) {
		return $post_id;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return $post_id;
	}
	if ( 'sliders' == $_POST['post_type'] ) {
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return $post_id;
		}
	}
	$mymeta = array('btn1_text', 'btn2_text', 'btn1_url', 'btn2_url', 'slide_align', 'extra_class');
	foreach ( $mymeta as $keys ) {
		if ( is_array( $_POST[ $keys ] ) ) {
			  $data = array();

			foreach ( $_POST[ $keys ] as $key => $value ) {
				$data[] = $value;
			}
		} else {
			$data = sanitize_text_field( $_POST[ $keys ] );
		}
		update_post_meta( $post_id, $keys, $data );
	}
}
add_action( 'save_post', 'save_rs_slider_meta' );