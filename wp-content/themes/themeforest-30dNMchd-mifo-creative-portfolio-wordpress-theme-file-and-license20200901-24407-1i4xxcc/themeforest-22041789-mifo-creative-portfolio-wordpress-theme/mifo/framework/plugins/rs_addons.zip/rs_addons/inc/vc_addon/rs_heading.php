<?php
/*
Element Description: Rs Custom Heading*/

    // Element Mapping
    function vc_infobox_mapping() {
         
        // Stop all if VC is not enabled
        if ( !defined( 'WPB_VC_VERSION' ) ) {
            return;
        }
         
        // Map the block with vc_map()
        vc_map( 
            array(
                'name' => __('Rs Heading', 'mifo'),
                'base' => 'vc_infobox',
                'description' => __('Rs heading box', 'mifo'), 
                'category' => __('by RS Theme', 'mifo'),   
                'icon' => get_template_directory_uri().'/framework/assets/img/vc-icon.png',           
                'params' => array(   
                         
			array(
				'type'        => 'textfield',
				'holder'      => 'h3',
				'class'       => 'title-class',
				'heading'     => __( 'Title', 'mifo' ),
				'param_name'  => 'title',
				'value'       => __( '', 'mifo' ),
				'description' => __( 'Heading title area', 'mifo' ),
				'admin_label' => false,
				'weight'      => 0,
			   
			),  
			 
			array(
				'type'        => 'textfield',
				'holder'      => 'h4',
				'class'       => 'text-class',
				'heading'     => __( 'Subtitle', 'mifo' ),
				'param_name'  => 'sub_text',
				'value'       => __( '', 'mifo' ),
				'description' => __( 'Sub title text here', 'mifo' ),
				'admin_label' => false,
				'weight'      => 0,                        
			),

			array(
				'type'        => 'textfield',
				'heading'     => __( 'Watermark Text', 'mifo' ),
				'param_name'  => 'watermark',
				'value'       => __( '', 'mifo' ),
				'description' => __( 'Watermark text here', 'mifo' ),                   
			),	

			array(
				'type'        => 'textarea_html',
				'heading'     => __( 'Text', 'mifo' ),
				'param_name'  => 'content',
				'value'       => __( '', 'mifo' ),
				'description' => __( 'Description text here', 'mifo' ),                    
			),
			array(
			    "type" => "dropdown",
			    "heading" => __("Select Align", "exposter"),
			    "param_name" => "align",
			    "value" => array(
			        __( 'Left', 'mifo' )   => '',
			        __( 'Center', 'mifo' ) => 'center',
			        __( 'Right', 'mifo' )  => 'right',
			    ),
			),
			array(
				'type'        => 'textfield',
				'heading'     => __( 'Extra class name', 'mifo' ),
				'param_name'  => 'el_class',
				'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'mifo' ),
			),		                     
						
			array(
			'type' => 'css_editor',
			'heading' => __( 'CSS box', 'mifo' ),
			'param_name' => 'css',
			'group' => __( 'Design Options', 'mifo' ),
			),                  
                        
         ),
      )
   );                          
        
}
 add_action( 'vc_before_init', 'vc_infobox_mapping' );
  
// Element HTML
function vc_infobox_html($atts, $content) {
         
        // Params extraction
        extract(
            shortcode_atts(
                array(
					'title'       => '',
					'sub_text'    => '',
					'watermark'    => '',
					'description' => '',
					'align'       => '',
					'el_class'    =>'',
					'css'         => ''
                ), 
                $atts, 'vc_infobox'
            )
        );

		//for css edit box value extract
		$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $atts );
		
         //custom class added
		$wrapper_classes = array($el_class) ;			
		$class_to_filter = implode( ' ', array_filter( $wrapper_classes ) );		
		$css_class_custom = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, $class_to_filter, $atts );

		$watermark_text = ($watermark) ? '<span class="watermark">'.esc_attr($watermark).'</span>' : '';
		$main_title = ($title) ? '<h2>'.$watermark_text.''.esc_attr($title).'</h2>' : '';
		$sub_text = ($sub_text) ? '<h3>'.esc_attr($sub_text).'</h3>' : '';  
         
        // Fill $html var with data
        $html = '
        <div class="rs-heading '.$css_class.' '.$css_class_custom.' '.$align.'">
        	<div class="title-inner">
	            '.$sub_text.'
	            '.$main_title.'
	        </div>';
	        if ($content) {
            	$html .= '<div class="description">'.$content.'</div>';
        	}
        $html .= '</div>';  	
         
        return $html;         
}
add_shortcode( 'vc_infobox', 'vc_infobox_html' );